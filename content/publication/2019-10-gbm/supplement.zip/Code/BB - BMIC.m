%GGM: Guseo & Guidolin, 2009

%% GGM: iPod
dataiPod = readtable('iPod.csv');
dNt = dataiPod.iPod_Units_Mill;
Nt = cumsum(dNt);
T = length(Nt);
p0 = 0.003;
q0 = 0.5;
c0 = -p0/(p0+q0); 
theta0 = [Nt(T)*1.5,c0,p0,q0];
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0,-1,0,0];
ub = [10000,0,1,1];
NLR = @(theta)nlrestBMIC(theta);
f1 = @(theta)NLSBMIC(theta,Nt);
[theta] = fmincon(f1,theta0,A,b,Aeq,beq,lb,ub,NLR);
Nth = zeros(length(Nt),1);
dNth = zeros(length(Nt),1);
for i=1:T
    Nth(i) = theta(1)*((theta(2)*(theta(3)+theta(4))+theta(3)*exp(-(theta(3)+theta(4))*i))/(theta(2)*(theta(3)+theta(4))-theta(4)*exp(-(theta(3)+theta(4))*i)));
    if i==1
        dNth(i) = Nth(i);
    else
        dNth(i) = Nth(i)-Nth(i-1);
    end
end

figure()
plot(Nt)
hold on
plot(Nth)
legend('Nt','Nth')
hold off

figure()
plot(dNt)
hold on
plot(dNth)
legend('dNt','dNth')
hold off

%% GGM: BlackBerry
dataBB = readtable('BlackberryNew.csv');
dNt = dataBB.BlackBerry_Units_Mills;
Nt = cumsum(dNt);
T = length(Nt);
theta0 = [Nt(T)*1.5,theta(2),theta(3),theta(4)];
t = 8;
BBEst = cumsum(dataBB.BlackBerry_Units_Mills(1:t));
f1 = @(theta)NLSBMIC(theta,BBEst);
[thetaBB] = fmincon(f1,theta0,A,b,Aeq,beq,lb,ub,NLR);
Nth = zeros(length(Nt),1);
dNth = zeros(length(Nt),1);
for i=1:T
    Nth(i) = thetaBB(1)*((thetaBB(2)*(thetaBB(3)+thetaBB(4))+thetaBB(3)*exp(-(thetaBB(3)+thetaBB(4))*i))/(thetaBB(2)*(thetaBB(3)+thetaBB(4))-thetaBB(4)*exp(-(thetaBB(3)+thetaBB(4))*i)));
    if i==1
        dNth(i) = Nth(i);
    else
        dNth(i) = Nth(i)-Nth(i-1);
    end
end

ResAbsdNt = zeros(T,1);
Res2dNt = zeros(T,1);
ResAbsNt = zeros(T,1);
Res2Nt = zeros(T,1);
for i=1:T
    ResAbsdNt(i) = abs(dNt(i)-dNth(i));
    Res2dNt(i) = (dNt(i)-dNth(i))^2;
    ResAbsNt(i) = abs(Nt(i)-Nth(i));
    Res2Nt(i) = (Nt(i)-Nth(i))^2;   
end

sum(ResAbsdNt)/T
(sum(Res2dNt)/T)^0.5
sum(ResAbsNt)/T
(sum(Res2Nt)/T)^0.5

figure()
plot(Nt)
hold on
plot(Nth)
legend('Nt','Nth')
hold off

figure()
plot(dNt)
hold on
plot(dNth)
legend('dNt','dNth')
hold off


    
