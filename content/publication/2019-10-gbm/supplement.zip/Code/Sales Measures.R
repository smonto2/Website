# Peak, Take-off and Saturation
library(inflection)

# Load some data
d1 <- read.csv('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/RACForecasts.csv')
d2 <- read.csv('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/BBForecasts.csv')
d3 <- read.csv('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/CNGForecasts.csv')

# Sales measures
sales_measures <- function(fs) {
    Time <- length(fs)
    peak <- which.max(fs)
    take1 <- mean(bede(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'EDE'])
    take2 <- mean(bese(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'ESE'])
    take3 <- ede(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']
    take4 <- ese(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']
    take <- c(take1, take2, take3, take4)

    sat1 <- mean(bede(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'EDE'])
    sat2 <- mean(bese(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'ESE'])
    sat3 <- ede(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']
    sat4 <- ese(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']
    sat <- c(sat1, sat2, sat3, sat4)

    return(list(peak = peak, takeoff = take, saturation = sat))
}

sales_measures2 <- function(fs) {
    Time <- length(fs)
    peak <- which.max(fs)
    take1 <- mean(bede(x = 1:Time, y = fs, index = 0)$iters[, 'EDE'])
    take2 <- mean(bese(x = 1:Time, y = fs, index = 0)$iters[, 'ESE'])
    take3 <- ede(x = 1:Time, y = fs, index = 0)[, 'chi']
    take4 <- ese(x = 1:Time, y = fs, index = 0)[, 'chi']
    take <- c(take1, take2, take3, take4)

    sat1 <- mean(bede(x = 1:Time, y = fs, index = 1)$iters[, 'EDE'])
    sat2 <- mean(bese(x = 1:Time, y = fs, index = 1)$iters[, 'ESE'])
    sat3 <- ede(x = 1:Time, y = fs, index = 1)[, 'chi']
    sat4 <- ese(x = 1:Time, y = fs, index = 1)[, 'chi']
    sat <- c(sat1, sat2, sat3, sat4)

    return(list(peak = peak, takeoff = take, saturation = sat))
}


sales_measures(d1$Obs)
sales_measures(d2$Obs)
sales_measures(d3$Obs)

apply(d1, 2, sales_measures)
apply(d2, 2, sales_measures)
apply(d3[2:11,2:11], 2, sales_measures)
apply(d3[ ,-(2:11)], 2, sales_measures2)
