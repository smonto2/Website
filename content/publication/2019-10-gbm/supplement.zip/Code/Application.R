# Clear data and import required packages
remove(list = ls())
library(mvtnorm)
library(rgenoud)
library(R2jags)

#
# Necessary functions
#

# Functions for estimating with covariates
formwc <- formula(Ss ~ m.ac*(((1 - exp(-(unit + X.ac[unit + 1, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit + X.ac[unit + 1, ]%*%b)*(p+q)))) - ((1 - exp(-(unit - 1 + X.ac[unit, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit - 1 + X.ac[unit, ]%*%b)*(p+q))))))
funwc <- function(pars, y, X, m) {
    p <- pars[1]; q <- pars[2]; betas <- pars[3:4]
    Time <- length(y); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- sum((y - m*diff(Ft))^2)
    return(res)
}

# Function for fitted values with covariates
fittedbayeswc <- function(pars, X, m) {
    p <- pars[1]; q <- pars[2]; betas <- pars[3:4]
    Time <- nrow(X); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- m*diff(Ft)
    return(res)
}

# Function for Bayesian estimation
bass <- function() {
    # Likelihood
    for (i in 1:Time) {
        y[i] ~ dnorm(mu[i], tau)
        mu[i] <- m*(((1 - exp(-(unit[i] + b[1]*x1[i+1] + b[2]*x2[i+1])*(p+q)))/(1 + (q/p)*exp(-(unit[i] + b[1]*x1[i+1] + b[2]*x2[i+1])*(p+q)))) - ((1 - exp(-(unit[i] - 1 + b[1]*x1[i] + b[2]*x2[i])*(p+q)))/(1 + (q/p)*exp(-(unit[i] - 1 + b[1]*x1[i] + b[2]*x2[i])*(p+q)))))
    }

    # Priors
    tempvar ~ dbeta(1, 1)
    tau <- (1 / kappa) * tempvar/(1 - tempvar)
    sigma <- 1/sqrt(tau)
    p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
    q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
    for (j in 3:4) {
        b[j - 2] ~ dt(locvec[j], 1/scalemat[j, j], 3)
    }
}

# Copying the data
datos.ac <- read.csv('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/ApplicationAC/Room AC.csv')

# Completing the necessary data
m.ac <- 18475
Time <- nrow(datos.ac)
unit <- 1:Time
datos.ac$Yt <- cumsum(datos.ac$Ss)
datos.ac$Yt2 <- datos.ac$Yt^2
datos.ac$unit <- 1:nrow(datos.ac)
X.ac <- rbind(0, cbind(log(datos.ac$Pr/datos.ac$Pr[1]), log(datos.ac$Sd/datos.ac$Sd[1])))

#
# Similar market
#
# Market for dryers
prev <- 1
locvec <- c(.0118, .2959, -.8117, .6583)     # Bass coef and std. err.
scalemat <- diag(c(.003, .0275, .567, .267)) #Informative
# scalemat <- diag(c(1000, 1000, 1000, 1000))
parnames <- c('p', 'q', 'b1', 'b2')
names(locvec) <- parnames
colnames(scalemat) <- rownames(scalemat) <- parnames
kappa <- 2000
pest <- runif(1, 0, 0.01)
qest <- runif(1, 0.2, 0.5)
pars <- list(p = pest, q = qest)
parswc <- list(p = pest, q = qest, b = rep(0, ncol(X.ac)))
pars.v <- unlist(pars)
pars.vwc <- unlist(parswc)

#
# Sequential Bayesian Estimation
#
# Data amounts and results list
Tvec <- c(0:Time)
reslist <- rep(list(NA), length(Tvec))
names(reslist) <- Tvec

coefmat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
semat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
fittedmat <- matrix(NA, nrow = length(Tvec), ncol = Time)
colnames(coefmat) <- colnames(semat) <- parnames
rownames(coefmat) <- rownames(semat) <- rownames(fittedmat) <- Tvec

for (i in 1:length(Tvec)) { #i in 1:length(Tvec) We didn't obtain estimates for t=0 and 3 using Non-informative prior 
    Time <- Tvec[i]
    if (Time != 0) {
        unit <- 1:Time
        datosT <- datos.ac[unit, ]
        XT <- X.ac[1:(Time + 1), ]

        # OLS regression for starting values
        # ols <- lm(Ss ~ Yt + Yt2, data = datosT) # Three data points necessary
        # a <- coef(ols)[3]; b <- coef(ols)[2]; c <- coef(ols)[1]
        # a <- unname(a); b <- unname(b); c <- unname(c)
        # mest <- (-b - sqrt(b^2 - 4*a*c))/(2*a)
        # pest <- c/mest; qest <- -a*mest
        # pars <- list(p = pest, q = qest)
        # parswc <- list(p = pest, q = qest, b = rep(0, ncol(XT)))
        # pars.v <- unlist(pars)
        # pars.vwc <- unlist(parswc)

        # Data case
        datos_list <- list(Time = Time, y = datosT$Ss, x1 = XT[ , 1],
                           x2 = XT[ , 2], unit = unit, m = m.ac,
                           locvec = locvec, scalemat = scalemat, kappa = kappa)
        n.iter <- 400000
        n.burnin <- n.iter/2
        n.thin <- 50
        monitor <- c('p', 'q', 'b', 'tau')
        jagsfit <- jags(data = datos_list, inits = list(parswc), monitor, n.chains = 1,
                        n.iter = n.iter, n.burnin = n.burnin, n.thin = n.thin, model.file = bass)
        coefmat[i, ] <- unlist(jagsfit$BUGSoutput$median[c('p', 'q', 'b')])
        semat[i, ] <- unlist(jagsfit$BUGSoutput$sd[c('p', 'q', 'b')])
        fittedmat[i, ] <- fittedbayeswc(coefmat[i, ], X.ac[-1, , drop = FALSE], m.ac)
        temp <- jagsfit$BUGSoutput$sims.matrix[ , c('p', 'q', 'b[1]', 'b[2]')]

        # Diagnostic results
        autoc <- autocorr.diag(as.mcmc(temp)) #, lags = 1:36)
        heidel <- heidel.diag(as.mcmc(temp))
        geweke <- geweke.diag(as.mcmc(temp))
        raftery <- raftery.diag(as.mcmc(temp))

        # Chain results
        reslist[[i]] <- list(Chains = temp, Diag = list(Autocorrelation = autoc,
                                                        Heidelberger = heidel, Geweke = geweke, Raftery = raftery))
    } else {
        # No data case
        temp <- rmvt(1e3, delta = locvec, sigma = scalemat, df = 3, type = 'shifted')
        coefmat[i, ] <- apply(temp, 2, mean)
        semat[i, ] <- apply(temp, 2, sd)
        fittedmat[i, ] <- fittedbayeswc(c(coefmat[i, 1:2], coefmat[i, 3:4]), X.ac[-1, , drop = FALSE], m.ac)

        # Saving results
        colnames(temp) <- parnames
        reslist[[i]] <- list(Chains = temp)
    }
}

# Forecast matrices
fittedmat <- t(fittedmat)
cumfittedmat <- apply(fittedmat, 2, cumsum)

# Noncumulative forecast plots
repp <- c(0, 3, 7, 8, 9, 10, 13)
setEPS()
postscript('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/ApplicationAC/FApp1.eps')
par(mar = c(4, 4, 1, 2) + 0.1)
plot(datos.ac$Ss, type = 'l', xlab = 'Time', ylab = 'Sales',
     ylim = c(0, max(fittedmat)))
sapply(1:length(repp), function(n) lines(fittedmat[ , repp[n] + 1], col = 1 + n, lty = 2))
legend(x = 'topleft', legend = c('Actual', paste(repp, 'data points')),
       col = c(1, 2:(length(repp) + 1)), lty = c(1, rep(2, length(repp))))
dev.off()

# Cumulative forecast plots
setEPS()
postscript('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/ApplicationAC/FApp2.eps')
par(mar = c(4, 4, 1, 2) + 0.1)
plot(datos.ac$Yt, type = 'l', xlab = 'Time', ylab = 'Sales',
     ylim = c(0, max(cumfittedmat)))
sapply(1:length(repp), function(n) lines(cumfittedmat[ , repp[n] + 1], col = 1 + n, lty = 2))
legend(x = 'topleft', legend = c('Actual', paste(repp, 'data points')),
       col = c(1, 2:(length(repp) + 1)), lty = c(1, rep(2, length(repp))))
dev.off()


# #
# # Adaptative plots
# #
#
# # Data matrices and plot limits
# zmatx <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$x)
# zmaty <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$y)
# zlimx <- rbind(apply(zmatx, 2, min), apply(zmatx, 2, max))
# zlimy <- rbind(apply(zmaty, 2, min), apply(zmaty, 2, max))
#
# densize <- length(density(reslist[[2]]$Chains[ , 1])$x)
# tmatx <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tmaty <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tlimx <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
# tlimy <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
#
# for (j in 1:6) {
#     for (i in 1:(length(Tvec) - 1)) {
#         tmatx[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$x
#         tmaty[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$y
#         tlimx[(2*i - 1):(2*i), j] <- c(min(tmatx[(densize*(i - 1) + 1):(densize*i), j]), max(tmatx[(densize*(i - 1) + 1):(densize*i), j]))
#         tlimy[(2*i - 1):(2*i), j] <- c(min(tmaty[(densize*(i - 1) + 1):(densize*i), j]), max(tmaty[(densize*(i - 1) + 1):(densize*i), j]))
#     }
# }
#
# # Plots
# for (j in 1:3) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = paste('Prior and posterior distributions for', parnames[j]),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }
#
# for (j in 4:6) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = substitute(paste(x, beta[n]), env = list(x = 'Prior and posterior distributions for ', n = j - 3)),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }

#
# Mean Errors
#
msefit <- sapply(1:(Time + 1), function(n) mean((fittedmat[ , n] - datos.ac$Ss)^2))
maefit <- sapply(1:(Time + 1), function(n) mean(abs(fittedmat[ , n] - datos.ac$Ss)))
msecumfit <- sapply(1:(Time + 1), function(n) mean((cumfittedmat[ , n] - datos.ac$Yt)^2))
maecumfit <- sapply(1:(Time + 1), function(n) mean(abs(cumfittedmat[ , n] - datos.ac$Yt)))

# One step-ahead forecast
osaf <- diag(fittedmat[ , -Time])
osafmse <- (osaf - datos.ac$Ss)^2
osafmae <- abs(osaf - datos.ac$Ss)

c(osafmse[repp + 1][-length(repp)], osafmse[repp][length(repp)-1])
c(osafmae[repp + 1][-length(repp)], osafmae[repp][length(repp)-1])

cumosaf <- diag(cumfittedmat[ , -Time])
cumosafmse <- (cumosaf - datos.ac$Yt)^2
cumosafmae <- abs(cumosaf - datos.ac$Yt)

c(cumosafmse[repp + 1][-length(repp)], cumosafmse[repp][length(repp)-1])
c(cumosafmae[repp + 1][-length(repp)], cumosafmae[repp][length(repp)-1])

# One step-ahead cumulative forecast plot
setEPS()
postscript('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/ApplicationAC/FApp3.eps')
par(mar = c(4, 4, 1, 2) + 0.1)
plot(datos.ac$Yt, type = 'l', xlab = 'Time', ylab = 'Sales',
     ylim = c(0, max(cumfittedmat)))
lines(cumosaf, col = 2, lty = 2)
legend(x = 'topleft', legend = c('Actual', 'One step-ahead'),
       col = c(1, 2), lty = c(1, 2))
dev.off()

#
# Sequential Frequentist (NLS) estimation
#

# Data amounts and results list
Time <- 13
Tvec <- c(8, 9, 10, 13)
reslist <- rep(list(NA), length(Tvec))
names(reslist) <- Tvec
formwc <- formula(Ss ~ m.ac*(((1 - exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))) - ((1 - exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q))))))

coefmat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
semat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
fittedmat <- matrix(NA, nrow = length(Tvec), ncol = Time)
colnames(coefmat) <- colnames(semat) <- parnames
rownames(coefmat) <- rownames(semat) <- rownames(fittedmat) <- Tvec

for (i in 1:length(Tvec)) {
    Time <- Tvec[i]
    unit <- 1:Time
    datosT <- datos.ac[unit, ]
    XT <- X.ac[1:(Time + 1), ]

    # Estimation with covariates
    print(Time)
    nlswc <- nls(formula = formwc, start = parswc, m = m.ac, data = datosT, algorithm = 'port', lower = c(0, 0, rep(-Inf, ncol(XT))), upper = c(1, 1, rep(Inf, ncol(XT))))
    nlminwc <- nlminb(objective = funwc, start = pars.vwc, m = m.ac, y = datosT$Ss, X = XT[-1, ], lower = c(0, 0, rep(-Inf, ncol(XT))), upper = c(1, 1, rep(Inf, ncol(XT))))
    uncwc <- optim(fn = funwc, par = pars.vwc, m = m.ac, y = datosT$Ss, X = XT[-1, ], hessian = TRUE)
    # genwc <- genoud(fn = funwc, nvars = 6, y = datos$Ss, X = X[-1, ], Domains = cbind(c(0, 0, -Inf, rep(-Inf, ncol(X))), c(1, 1, Inf, rep(Inf, ncol(X)))), hessian = TRUE, max.generations = 150)


    # Saving results
    coefmat[i, ] <- coef(nlswc)
    semat[i, ] <- summary(nlswc)$coefficients[, 'Std. Error']
    fittedmat[i, ] <- fittedbayeswc(coefmat[i, ], X.ac[-1, , drop = FALSE], m = m.ac)
    reslist[[i]] <- nlswc
}

msefit <- sapply(1:length(Tvec), function(n) mean((fittedmat[ , n] - datos.ac$Ss)^2))
maefit <- sapply(1:length(Tvec), function(n) mean(abs(fittedmat[ , n] - datos.ac$Ss)))
msecumfit <- sapply(1:length(Tvec), function(n) mean((cumfittedmat[ , n] - datos.ac$Yt)^2))
maecumfit <- sapply(1:length(Tvec), function(n) mean(abs(cumfittedmat[ , n] - datos.ac$Yt)))
