# Remove previous objects
remove(list = ls())
library(R2jags)

# Read data
dat <- read.csv('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/BlackberryNew.csv')
datos<-dat[1:8,]
# Bayesian BM model for JAGS
bass_bm <- function() {
  # Likelihood
  for (i in 1:Time) {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- m*((1 - exp(-(p+q)*i))/(1 + (q/p)*exp(-(p+q)*i)) - (1 - exp(-(p+q)*(i-1)))/(1 + (q/p)*exp(-(p+q)*(i-1))))
  }
  
  # Priors
  tempvar ~ dbeta(1, 1)
  tau <- (1 / kappa) * tempvar/(1 - tempvar)
  sigma2 <- 1/tau
  p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
  q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
  m ~ dt(locvec[3],  1/scalemat[3, 3], 3)
}

# Bayesian GBM model for JAGS
bass_gbm <- function() {
  # Likelihood
  for (i in 1:Time) {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- m*((1 - exp(-(p + q)*(i + X[i + 1, ]*betas)))/(1 + (q/p)*exp(-(p + q)*(i + X[i + 1, ]*betas))) - (1 - exp(-(p + q)*(i - 1 + X[i, ]*betas)))/(1 + (q/p)*exp(-(p + q)*(i - 1 + X[i, ]*betas))))
  }
  
  # Priors
  tempvar ~ dbeta(1, 1)
  tau <- (1 / kappa) * tempvar/(1 - tempvar)
  sigma2 <- 1/tau
  p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
  q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
  m ~ dt(locvec[3],  1/scalemat[3, 3], 3)
  for (j in 4:(k+3)) {
    betas[j - 3] ~ dt(locvec[j],  1/scalemat[j, j], 3)
  }
}

# Completing the necessary data for OLS
datos$Ss<-datos$BlackBerry_Units_Mills
Time <- length(datos$Ss)
datos$Nt <- c(0, cumsum(datos$Ss[-Time]))
datos$Nt2 <- datos$Nt^2
datos$tt <- 1:Time

# OLS regression for starting values
ols <- lm(Ss ~ Nt + Nt2, data = datos)
alpha <- unname(coef(ols))
mest <- (-alpha[2] - sqrt(alpha[2]^2 - 4*alpha[1]*alpha[3]))/(2*alpha[3])
# mest <- 250 #Solo para t=3 pq falla
pest <- alpha[1]/mest
qest <- -mest*alpha[3]
ols_coef <- c(pest, qest, mest)
round(ols_coef, 4)

# Cumulative marketing effort
datos$Pr<-datos$Price_US/datos$USA_CPI_2002*100
covars <- cbind(datos$Pr)
X <- rbind(0, apply(covars, 2, function(x) log(x/x[1])))
k <- ncol(X)

# Priors and Gibbs beginning values
pars_bm <- ols_coef
pars_gbm_l <- list(p = pars_bm[1], q = pars_bm[2], m = pars_bm[3], betas = rep(0, k))
names(pars_bm) <- c('p', 'q', 'm')
locvec_bm <- c(0.003780982,0.532061621,424.260289013)#rep(0, 3 + k)
scalemat_bm <- diag(c(0.003010854^2,0.039804179^2,23.686192988^2))

#log(0.532061621/0.003780982)/(0.003780982+0.532061621)
#We use iPod data to build priors. These results were obtained using NLS
locvec_gbm <- c(0.003780982,0.532061621,424.260289013,-0.98985317)#rep(0, 3 + k)
scalemat_gbm <- diag(c(0.003010854^2,0.039804179^2,23.686192988^2,0.680142686^2)) 
kappa <- 5*var(datos$Ss)

# Bayesian estimation
datos_list_bm <- list(Time = Time, y = datos$Ss, kappa = kappa,
                      locvec = locvec_bm, scalemat = scalemat_bm)
datos_list_gbm <- list(Time = Time, y = datos$Ss, X = X, k = k, kappa = kappa,
                       locvec = locvec_gbm, scalemat = scalemat_gbm)
n.chains <- 3
inits_bm <- rep(list(as.list(pars_bm)), n.chains)
inits_gbm <-rep(list(pars_gbm_l), n.chains)
params_bm <- c('p', 'q', 'm', 'sigma2')
params_gbm <- c('p', 'q', 'm', 'betas', 'sigma2')
n.iter <- 50000
n.burnin <- n.iter/2
n.thin <- 5

# JAGS estimation (might have to run the GBM a couple of times)
jagsfit_bm <- jags(data = datos_list_bm, inits = inits_bm, parameters.to.save = params_bm,
                   model.file = bass_bm, n.chains = n.chains, n.iter = n.iter,
                   n.burnin = n.burnin, progress.bar = 'gui')
summary(mcmc(jagsfit_bm$chains))
jagsfit_gbm <- jags(data = datos_list_gbm, inits = inits_gbm, parameters.to.save = params_gbm,
                    model.file = bass_gbm, n.chains = n.chains, n.iter = n.iter,
                    n.burnin = n.burnin, progress.bar = 'gui')
PARAMETROS.POSTERIORES_GBM <- data.frame(jagsfit_gbm$BUGSoutput$sims.list$p,
                                         jagsfit_gbm$BUGSoutput$sims.list$q,
                                         jagsfit_gbm$BUGSoutput$sims.list$m,
                                         jagsfit_gbm$BUGSoutput$sims.list$betas)

summary(mcmc(PARAMETROS.POSTERIORES_GBM))
write.csv(PARAMETROS.POSTERIORES_GBM,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/PosteriorChainsBlackb_3.csv")

############Forecast############
# GBM
dat <- read.csv('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/BlackberryNew.csv')
datos<-dat[,]
# Completing the necessary data for OLS
datos$Ss<-datos$BlackBerry_Units_Mills
Time <- length(datos$Ss)
datos$Nt <- c(0, cumsum(datos$Ss[-Time]))
datos$Nt2 <- datos$Nt^2
datos$tt <- 1:Time

# Cumulative marketing effort
datos$Pr<-datos$Price_US/datos$USA_CPI_2002*100
covars <- cbind(datos$Pr)
X <- rbind(0, apply(covars, 2, function(x) log(x/x[1])))
k <- ncol(X)



nls_gbm_forecast <- function(para){
  p<-para[1]
  q<-para[2]
  m<-para[3]
  betas<-para[4]
  Ss.For<- m*((1 - exp(-(p + q)*(tt + X[tt + 1, ]*betas)))/(1 + (q/p)*exp(-(p + q)*(tt + X[tt + 1, ]*betas))) - (1 - exp(-(p + q)*(tt - 1 + X[tt, ]*betas)))/(1 + (q/p)*exp(-(p + q)*(tt - 1 + X[tt, ]*betas))))
}
tt<-1:Time
ForecastsAll<-apply(PARAMETROS.POSTERIORES_GBM,1,nls_gbm_forecast)
Forecasts<-rowMeans(ForecastsAll)
View(Forecasts)
write.csv(Forecasts,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/Forecast3Blackb.csv")

CredInt95<-apply(ForecastsAll,1,function(x) quantile(x,c(0.025,0.5,0.975)))
write.csv(t(CredInt95),"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/CredInt95Blackb_3.csv")

(sum((datos$Ss-Forecasts)^2)/length(tt))^0.5
(sum(abs(datos$Ss-Forecasts))/length(tt))

(sum((cumsum(datos$Ss)-cumsum(Forecasts))^2)/length(tt))^0.5
(sum(abs(datos$Ss-Forecasts))/length(tt))

# ############NO DATA###########
# S<-3000
# library(tmvtnorm)
# p<- rtmvt(S,0.0037, 0.0030, 3)
# q<- rtmvt(S,0.5320, 0.0398, 3)
# m<- rtmvt(S,424.2602, 23.6861, 3)
# betas<- rtmvt(S,-0.9898, 0.6801, 3)
# post<-cbind(p,q,m,betas)
# #post<-cbind(0.007,0.68,270,0)
# summary(mcmc(post))
# write.csv(post,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/PosteriorChainsBlackBerry0.csv")
# Forecasts<-rowMeans(apply(post,1,nls_gbm_forecast))
# (sum((datos$Ss-Forecasts)^2)/length(tt))^0.5
# (sum(abs(datos$Ss-Forecasts))/length(tt))
# 
# write.csv(Forecasts,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/Forecast0BlackBerry.csv")
# 
# ########################################################################
