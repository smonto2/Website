#
# Simulation exercise
#
remove(list = ls())
graphics.off()
parnames <- c('p', 'q', 'm', 'b1', 'b2', 'b3')
datos <- read.csv('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/Simulation.csv')
Time <- nrow(datos)
X <- rbind(0, apply(as.matrix(datos[, c('x1', 'x2', 'x3')]), 2, function(x) log(x/x[1])))

# Functions for estimating with covariates
formwc <- formula(Ss ~ m*(((1 - exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))) - ((1 - exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q))))))
funwc <- function(pars, y, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- length(y); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- sum((y - m*diff(Ft))^2)
    return(res)
}

# Function for fitted values with covariates
fittedbayeswc <- function(pars, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- nrow(X); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- m*diff(Ft)
    return(res)
}

# Sales measures
sales_measures <- function(fs) {
    peak <- which.max(fs)
    take1 <- mean(bede(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'EDE'])
    take2 <- mean(bese(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'ESE'])
    take3 <- ede(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']
    take4 <- ese(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']

    sat1 <- mean(bede(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'EDE'])
    sat2 <- mean(bese(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'ESE'])
    sat3 <- ede(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']
    sat4 <- ese(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']

    return(list(peak = peak, takeoff = c(take1, take2, take3, take4),
                saturation = c(sat1, sat2, sat3, sat4)))
}

# Data amounts and results list
Tvec <- c(8, 9, 10, 15, 20, 24)
reslist <- rep(list(NA), length(Tvec))
names(reslist) <- Tvec

coefmat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
semat <- matrix(NA, nrow = length(Tvec), ncol = length(parnames))
fittedmat <- matrix(NA, nrow = length(Tvec), ncol = Time)
colnames(coefmat) <- colnames(semat) <- parnames
rownames(coefmat) <- rownames(semat) <- rownames(fittedmat) <- Tvec

for (i in 1:length(Tvec)) {
    Time <- Tvec[i]
    unit <- 1:Time
    datosT <- datos[unit, ]
    XT <- X[1:(Time + 1), ]

    # OLS regression for starting values
    ols <- lm(Ss ~ Nt + Nt2, data = datosT) # Three data points necessary
    a <- coef(ols)[3]; b <- coef(ols)[2]; c <- coef(ols)[1]
    a <- unname(a); b <- unname(b); c <- unname(c)
    mest <- (-b - sqrt(b^2 - 4*a*c))/(2*a)
    pest <- c/mest; qest <- -a*mest
    pars <- list(p = pest, q = qest, m = mest)
    parswc <- list(p = pest, q = qest, m = mest, b = rep(0, ncol(XT)))
    pars.v <- unlist(pars)
    pars.vwc <- unlist(parswc)

    # Estimation with covariates
    print(Time)
    nlswc <- nls(formula = formwc, start = parswc, data = datosT, algorithm = 'port', lower = c(0, 0, 0, rep(-Inf, ncol(X))), upper = c(1, 1, 100000, rep(Inf, ncol(X))))
    uncwc <- optim(fn = funwc, par = pars.vwc, y = datosT$Ss, X = XT[-1, ], hessian = TRUE)
    # genwc <- genoud(fn = funwc, nvars = 6, y = datos$Ss, X = X[-1, ], Domains = cbind(c(0, 0, -Inf, rep(-Inf, ncol(X))), c(1, 1, Inf, rep(Inf, ncol(X)))), hessian = TRUE, max.generations = 150)


    # Saving results
    coefmat[i, ] <- coef(nlswc)
    semat[i, ] <- summary(nlswc)$coefficients[, 'Std. Error']
    fittedmat[i, ] <- fittedbayeswc(coefmat[i, ], X[-1, , drop = FALSE])
    reslist[[i]] <- nlswc
}

# Forecast matrices
fittedmat <- t(fittedmat)
cumfittedmat <- apply(fittedmat, 2, cumsum)

# Summary measures
xtable(t(coefmat), digits = 3)
xtable(t(semat), digits = 3)
apply(fittedmat, 2, sales_measures)

# Cumulative forecast plots
reppoints <- c(0, 5, 10, 25)
setEPS()
postscript('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Tex/FEx1.eps')
plot(datos$Yt, type = 'l', main = 'Cumulative Sales', xlab = 'Years', ylab = 'Sales',
     ylim = c(0, max(fittedmat)))
sapply(1:length(Tvec), function(n) lines(fittedmat[ , n], col = 1 + n, lty = 2))
legend(x = 'topleft', legend = c('Simulated', paste(reppoints, 'data points')),
       col = c(1, reppoints + 2), lty = c(1, rep(2, length(reppoints))))
dev.off()

# #
# # Adaptative plots
# #
#
# # Data matrices and plot limits
# zmatx <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$x)
# zmaty <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$y)
# zlimx <- rbind(apply(zmatx, 2, min), apply(zmatx, 2, max))
# zlimy <- rbind(apply(zmaty, 2, min), apply(zmaty, 2, max))
#
# densize <- length(density(reslist[[2]]$Chains[ , 1])$x)
# tmatx <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tmaty <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tlimx <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
# tlimy <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
#
# for (j in 1:6) {
#     for (i in 1:(length(Tvec) - 1)) {
#         tmatx[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$x
#         tmaty[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$y
#         tlimx[(2*i - 1):(2*i), j] <- c(min(tmatx[(densize*(i - 1) + 1):(densize*i), j]), max(tmatx[(densize*(i - 1) + 1):(densize*i), j]))
#         tlimy[(2*i - 1):(2*i), j] <- c(min(tmaty[(densize*(i - 1) + 1):(densize*i), j]), max(tmaty[(densize*(i - 1) + 1):(densize*i), j]))
#     }
# }
#
# # Plots
# for (j in 1:3) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = paste('Prior and posterior distributions for', parnames[j]),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }
#
# for (j in 4:6) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = substitute(paste(x, beta[n]), env = list(x = 'Prior and posterior distributions for ', n = j - 3)),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }

#
# Mean Errors
#
msefit <- sapply(1:length(Tvec), function(n) mean((fittedmat[ , n] - datos$Ss)^2))
maefit <- sapply(1:length(Tvec), function(n) mean(abs(fittedmat[ , n] - datos$Ss)))
msecumfit <- sapply(1:length(Tvec), function(n) mean((cumfittedmat[ , n] - datos$Ss)^2))
maecumfit <- sapply(1:length(Tvec), function(n) mean(abs(cumfittedmat[ , n] - datos$Ss)))

# One step-ahead forecast
osaf <- diag(fittedmat[Tvec + 1, ])
osafmse <- (osaf - datos$Ss[Tvec + 1])^2
osafmae <- abs(osaf - datos$Ss[Tvec + 1])

# c(osafmse[repp + 1][-length(repp)], osafmse[repp][length(repp)-1])
# c(osafmae[repp + 1][-length(repp)], osafmae[repp][length(repp)-1])

cumosaf <- diag(cumfittedmat[Tvec + 1, ])
cumosafmse <- (cumosaf - cumsum(datos$Ss)[Tvec + 1])^2
cumosafmae <- abs(cumosaf - cumsum(datos$Ss)[Tvec + 1])

# c(cumosafmse[repp + 1][-length(repp)], cumosafmse[repp][length(repp)-1])
# c(cumosafmae[repp + 1][-length(repp)], cumosafmae[repp][length(repp)-1])
