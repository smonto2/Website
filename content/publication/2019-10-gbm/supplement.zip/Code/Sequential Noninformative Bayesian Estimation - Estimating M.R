# Sequential Bayesian Estimation of GBM
# Estimating m
remove(list = ls())
graphics.off()
require(mvtnorm)
require(R2jags)

parnames <- c('p', 'q', 'm', 'b1', 'b2', 'b3')
parl <- length(parnames)
datos <- read.csv('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/Simulation.csv')
Time <- nrow(datos)
X <- rbind(0, apply(as.matrix(datos[, c('x1', 'x2', 'x3')]), 2, function(x) log(x/x[1])))
k <- ncol(X)

# Previous arbitrary markets
locvec <- rep(0, parl)
scalemat <- 1000*diag(parl)
kappa <- 2000

# Function for Bayesian estimation
bass <- function() {
    # Likelihood
    for (i in 1:Time) {
        y[i] ~ dnorm(mu[i], tau)
        mu[i] <- m*((1 - exp(-(p + q)*(i + X[i + 1, ]%*%betas)))/(1 + (q/p)*exp(-(p + q)*(i + X[i + 1, ]%*%betas))) - (1 - exp(-(p + q)*(i - 1 + X[i, ]%*%betas)))/(1 + (q/p)*exp(-(p + q)*(i - 1 + X[i, ]%*%betas))))
    }

    # Priors
    tempvar ~ dbeta(1, 1)
    tau <- (1 / kappa) * tempvar/(1 - tempvar)
    sigma2 <- 1/tau
    p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
    q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
    m ~ dt(locvec[3],  1/scalemat[3, 3], 3)
    for (j in 4:(k+3)) {
        betas[j - 3] ~ dt(locvec[j],  1/scalemat[j, j], 3)
    }
}

# Function for fitted values with covariates
# You input a parameter vector and a matrix of covariates and this function
# returns the non-cumulative sales
fittedbayeswc <- function(pars, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- nrow(X); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- m*diff(Ft)
    return(res)
}

# Sales measures
sales_measures <- function(fs) {
    peak <- which.max(fs)
    take1 <- mean(bede(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'EDE'])
    take2 <- mean(bese(x = 1:peak, y = fs[1:peak], index = 0)$iters[, 'ESE'])
    take3 <- ede(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']
    take4 <- ese(x = 1:peak, y = fs[1:peak], index = 0)[, 'chi']

    sat1 <- mean(bede(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'EDE'])
    sat2 <- mean(bese(x = peak:Time, y = fs[peak:Time], index = 1)$iters[, 'ESE'])
    sat3 <- ede(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']
    sat4 <- ese(x = peak:Time, y = fs[peak:Time], index = 1)[, 'chi']

    return(list(peak = peak, takeoff = c(take1, take2, take3, take4),
                saturation = c(sat1, sat2, sat3, sat4)))
}

# Data amounts and results list
Tvec <- c(0, 8, 9, 10, 15, 20, 24)
reslist <- rep(list(NA), length(Tvec))
names(reslist) <- Tvec

# Empty matrices to be filled up with the results from the simulation
coefmat <- matrix(NA, nrow = length(Tvec), ncol = parl)
semat <- matrix(NA, nrow = length(Tvec), ncol = parl)
fittedmat <- matrix(NA, nrow = length(Tvec), ncol = Time)
colnames(coefmat) <- colnames(semat) <- parnames
rownames(coefmat) <- rownames(semat) <- rownames(fittedmat) <- Tvec

for (i in 1:length(Tvec)) {
    Time <- Tvec[i]
    if (Time != 0) {
        unit <- 1:Time
        datosT <- datos[unit, ]
        XT <- X[1:(Time + 1), ]

        # OLS regression for starting values
        ols <- lm(Ss ~ Nt + Nt2, data = datosT) # Three data points necessary
        a <- coef(ols)[3]; b <- coef(ols)[2]; c <- coef(ols)[1]
        a <- unname(a); b <- unname(b); c <- unname(c)
        mest <- (-b - sqrt(b^2 - 4*a*c))/(2*a)
        pest <- c/mest; qest <- -a*mest
        parswc <- list(p = pest, q = qest, m = mest, betas = rep(0, ncol(XT)))
        pars.vwc <- unlist(parswc)

        # Data case
        datos_list <- list(Time = Time, y = datosT$Ss, X = XT, k = k, kappa = kappa,
                           locvec = locvec, scalemat = scalemat)
        n.iter <- 50000 # Iterations
        n.burnin <- n.iter/2 # Burn-in
        n.thin <- 5 # Thinning
        n.chains <- 3
        monitor <- c('p', 'q', 'm', 'betas', 'sigma2')
        jagsfit <- jags(data = datos_list, inits = rep(list(parswc), n.chains),
                        parameters.to.save = monitor, model.file = bass,
                        n.chains = n.chains, n.iter = n.iter, n.burnin = n.burnin)
        coefmat[i, ] <- unlist(jagsfit$BUGSoutput$mean[c('p', 'q', 'm', 'betas')])
        semat[i, ] <- unlist(jagsfit$BUGSoutput$sd[c('p', 'q', 'm', 'betas')])
        fittedmat[i, ] <- fittedbayeswc(coefmat[i, ], X[-1, , drop = FALSE])
        temp <- jagsfit$BUGSoutput$sims.matrix[ , c('p', 'q', 'm', 'betas[1]', 'betas[2]', 'betas[3]')]

        # Diagnostic results
        autoc <- autocorr.diag(as.mcmc(temp)) #, lags = 1:36)
        heidel <- heidel.diag(as.mcmc(temp))
        geweke <- geweke.diag(as.mcmc(temp))
        raftery <- raftery.diag(as.mcmc(temp))

        # Chain results
        reslist[[i]] <- list(Chains = temp, Diag = list(Autocorrelation = autoc,
                                                        Heidelberger = heidel, Geweke = geweke, Raftery = raftery))
    } else {
        # No data case
        temp <- rmvt(1e3, delta = locvec, sigma = scalemat, df = 3, type = 'shifted')
        coefmat[i, ] <- apply(temp, 2, mean)
        semat[i, ] <- apply(temp, 2, sd)
        fittedmat[i, ] <- fittedbayeswc(coefmat[i, ], X[-1, , drop = FALSE])

        # Saving results
        colnames(temp) <- parnames
        reslist[[i]] <- list(Chains = temp)
    }
}

# Forecast matrices
fittedmat <- t(fittedmat)
cumfittedmat <- apply(fittedmat, 2, cumsum)

# Summary measures
t(coefmat)
t(semat)
apply(fittedmat, 2, sales_measures)

# Cumulative forecast plots
repp <- c(0, 5, 10, 20, 25)
setEPS()
postscript('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Tex/FEx1.eps')
par(mar = c(4, 4, 1, 2) + 0.1)
plot(datos$Yt, type = 'l', xlab = 'Time', ylab = 'Sales',
     ylim = c(0, max(cumfittedmat)))
sapply(1:length(repp), function(n) lines(cumfittedmat[ , repp[n] + 1], col = 1,
                                         type = 'b', pch = n - 1))
legend(x = 'topleft', legend = c('Simulated', paste(repp, 'data points')),
       col = 1, lty = c(1, rep(NA, length(repp))), pch = c(NA, 0:(length(repp) - 1)))
dev.off()

#
# Adaptative plots
#

# Data matrices and plot limits
# Here I recover the final matrices from the list 'reslist'
# The next step is purely aesthetical, what I do is find the limits
# ylim and xlim for the plots so that all of the lines will be inside
# of the plot region
repp <- c(10, 15, 20, 25)
zmatx <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$x)
zmaty <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$y)
zlimx <- rbind(apply(zmatx, 2, min), apply(zmatx, 2, max))
zlimy <- rbind(apply(zmaty, 2, min), apply(zmaty, 2, max))

densize <- length(density(reslist[[2]]$Chains[ , 1])$x)
tmatx <- matrix(NA, nrow = densize*(length(repp) - 1), ncol = 6)
tmaty <- matrix(NA, nrow = densize*(length(repp) - 1), ncol = 6)
tlimx <- matrix(NA, nrow = 2*(length(repp) - 1), ncol = 6)
tlimy <- matrix(NA, nrow = 2*(length(repp) - 1), ncol = 6)

for (j in 1:6) {
    for (i in 1:(length(repp) - 1)) {
        tmatx[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$x
        tmaty[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$y
        tlimx[(2*i - 1):(2*i), j] <- c(min(tmatx[(densize*(i - 1) + 1):(densize*i), j]), max(tmatx[(densize*(i - 1) + 1):(densize*i), j]))
        tlimy[(2*i - 1):(2*i), j] <- c(min(tmaty[(densize*(i - 1) + 1):(densize*i), j]), max(tmaty[(densize*(i - 1) + 1):(densize*i), j]))
    }
}

# Plots for the parameter densities
for (j in 1:3) {
    filename <- paste0('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Tex/','FAdapt', j, '_', parnames[j], '.eps')
    setEPS()
    postscript(filename)
    par(mar = c(4, 4, 1, 2) + 0.1)
    plot(zmatx[ , j], zmaty[ , j], type = 'l',
         xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j]))),
         ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
    )
    for (i in 1:(length(repp) - 1)) {
        lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], lty = i + 2)
    }
    abline(v = pobpars[j], lty = 2)
    legend(x = 'topright', legend = c('Prior', 'Population Value', paste(repp, 'data points')),
           lty = 1:6)
    dev.off()
}

for (j in 4:6) {
    dev.new()
    plot(zmatx[ , j], zmaty[ , j], type = 'l', main = substitute(paste(x, beta[n]), env = list(x = 'Prior and posterior distributions for ', n = j - 3)),
         xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j]))),
         ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
    )
    for (i in 1:(length(repp) - 1)) {
        lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], type = 'b', pch = i - 1)
    }
    abline(v = pobpars[j], lty = 2)
    legend(x = 'topleft', legend = c('Prior', 'Population Value', paste(repp[-1], 'data points')),
           col = c(1, 1, 2:length(repp)), lty = c(1, 2, rep(2, length(repp) - 1)))
}

#
# Mean Errors
#
msefit <- sapply(1:length(Tvec), function(n) mean((fittedmat[ , n] - datos$Ss)^2))
maefit <- sapply(1:length(Tvec), function(n) mean(abs(fittedmat[ , n] - datos$Ss)))
msecumfit <- sapply(1:length(Tvec), function(n) mean((cumfittedmat[ , n] - datos$Ss)^2))
maecumfit <- sapply(1:length(Tvec), function(n) mean(abs(cumfittedmat[ , n] - datos$Ss)))

# One step-ahead forecast
osaf <- diag(fittedmat[Tvec + 1, ])
osafmse <- (osaf - datos$Ss[Tvec + 1])^2
osafmae <- abs(osaf - datos$Ss[Tvec + 1])

# c(osafmse[repp + 1][-length(repp)], osafmse[repp][length(repp)-1])
# c(osafmae[repp + 1][-length(repp)], osafmae[repp][length(repp)-1])

cumosaf <- diag(cumfittedmat[Tvec + 1, ])
cumosafmse <- (cumosaf - cumsum(datos$Ss)[Tvec + 1])^2
cumosafmae <- abs(cumosaf - cumsum(datos$Ss)[Tvec + 1])

# c(cumosafmse[repp + 1][-length(repp)], cumosafmse[repp][length(repp)-1])
# c(cumosafmae[repp + 1][-length(repp)], cumosafmae[repp][length(repp)-1])

xtable(rbind(osafmse, osafmae, cumosafmse, cumosafmae), digits = 2)
