# Remove previous objects
remove(list = ls())
library(R2jags)

# Read data
dat <- read.csv('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/BlackberryNew.csv')
datos<-dat[1:8,]
# Bayesian BM model for JAGS
bass_bm <- function() {
  # Likelihood
  for (i in 1:Time) {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- m*((1 - exp(-(p+q)*i))/(1 + (q/p)*exp(-(p+q)*i)) - (1 - exp(-(p+q)*(i-1)))/(1 + (q/p)*exp(-(p+q)*(i-1))))
  }
  
  # Priors
  tempvar ~ dbeta(1, 1)
  tau <- (1 / kappa) * tempvar/(1 - tempvar)
  sigma2 <- 1/tau
  p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
  q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
  m ~ dt(locvec[3],  1/scalemat[3, 3], 3)
}

# Completing the necessary data for OLS
datos$Ss<-datos$BlackBerry_Units_Mills
Time <- length(datos$Ss)
datos$Nt <- c(0, cumsum(datos$Ss[-Time]))
datos$Nt2 <- datos$Nt^2
datos$tt <- 1:Time

# OLS regression for starting values
ols <- lm(Ss ~ Nt + Nt2, data = datos)
alpha <- unname(coef(ols))
mest <- (-alpha[2] - sqrt(alpha[2]^2 - 4*alpha[1]*alpha[3]))/(2*alpha[3])
# mest <- 250 #Solo para t=3 pq falla
pest <- alpha[1]/mest
qest <- -mest*alpha[3]
ols_coef <- c(pest, qest, mest)
round(ols_coef, 4)

# Cumulative marketing effort
datos$Pr<-datos$Price_US/datos$USA_CPI_2002*100
covars <- cbind(datos$Pr)
X <- rbind(0, apply(covars, 2, function(x) log(x/x[1])))
k <- ncol(X)

# Priors and Gibbs beginning values
pars_bm <- ols_coef
pars_gbm_l <- list(p = pars_bm[1], q = pars_bm[2], m = pars_bm[3], betas = rep(0, k))
names(pars_bm) <- c('p', 'q', 'm')
locvec_bm <- c(0.003780982,0.532061621,424.260289013)#rep(0, 3 + k)
scalemat_bm <- diag(c(0.003010854^2,0.039804179^2,23.686192988^2))
kappa <- 5*var(datos$Ss)

# Bayesian estimation
datos_list_bm <- list(Time = Time, y = datos$Ss, kappa = kappa,
                      locvec = locvec_bm, scalemat = scalemat_bm)
n.chains <- 3
inits_bm <- rep(list(as.list(pars_bm)), n.chains)
params_bm <- c('p', 'q', 'm', 'sigma2')
n.iter <- 50000
n.burnin <- n.iter/2
n.thin <- 5

# JAGS estimation (might have to run the GBM a couple of times)
jagsfit_bm <- jags(data = datos_list_bm, inits = inits_bm, parameters.to.save = params_bm,
                   model.file = bass_bm, n.chains = n.chains, n.iter = n.iter,
                   n.burnin = n.burnin, progress.bar = 'gui')
PARAMETROS.POSTERIORES_BM <- data.frame(jagsfit_bm$BUGSoutput$sims.list$p,
                                         jagsfit_bm$BUGSoutput$sims.list$q,
                                         jagsfit_bm$BUGSoutput$sims.list$m)

summary(mcmc(PARAMETROS.POSTERIORES_BM))


# write.csv(PARAMETROS.POSTERIORES_BM,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/PosteriorChainsBlackb_3.csv")

############Forecast############
# GBM
dat <- read.csv('C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/BlackberryNew.csv')
datos<-dat[,]
# Completing the necessary data for OLS
datos$Ss<-datos$BlackBerry_Units_Mills
Time <- length(datos$Ss)
datos$Nt <- c(0, cumsum(datos$Ss[-Time]))
datos$Nt2 <- datos$Nt^2
datos$tt <- 1:Time

# Cumulative marketing effort
datos$Pr<-datos$Price_US/datos$USA_CPI_2002*100
covars <- cbind(datos$Pr)
X <- rbind(0, apply(covars, 2, function(x) log(x/x[1])))
k <- ncol(X)



nls_bm_forecast <- function(para){
  p<-para[1]
  q<-para[2]
  m<-para[3]
  betas<-para[4]
  Ss.For<- m*((1 - exp(-(p + q)*tt))/(1 + (q/p)*exp(-(p + q)*tt)) - (1 - exp(-(p + q)*(tt - 1)))/(1 + (q/p)*exp(-(p + q)*(tt - 1))))
}
tt<-1:Time
ForecastsAll<-apply(PARAMETROS.POSTERIORES_BM,1,nls_bm_forecast)
Forecasts<-rowMeans(ForecastsAll)
View(Forecasts)
# write.csv(Forecasts,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/Forecast3Blackb.csv")

# CredInt95<-apply(ForecastsAll,1,function(x) quantile(x,c(0.025,0.5,0.975)))
# write.csv(t(CredInt95),"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/CredInt95Blackb_3.csv")

(sum((datos$Ss-Forecasts)^2)/length(tt))^0.5
(sum(abs(datos$Ss-Forecasts))/length(tt))

(sum((cumsum(datos$Ss)-cumsum(Forecasts))^2)/length(tt))^0.5
(sum(abs(datos$Ss-Forecasts))/length(tt))

# ############NO DATA###########
# S<-3000
# library(tmvtnorm)
# p<- rtmvt(S,0.0037, 0.0030, 3)
# q<- rtmvt(S,0.5320, 0.0398, 3)
# m<- rtmvt(S,424.2602, 23.6861, 3)
# betas<- rtmvt(S,-0.9898, 0.6801, 3)
# post<-cbind(p,q,m,betas)
# #post<-cbind(0.007,0.68,270,0)
# summary(mcmc(post))
# write.csv(post,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/PosteriorChainsBlackBerry0.csv")
# Forecasts<-rowMeans(apply(post,1,nls_gbm_forecast))
# (sum((datos$Ss-Forecasts)^2)/length(tt))^0.5
# (sum(abs(datos$Ss-Forecasts))/length(tt))
# 
# write.csv(Forecasts,"C:/ANDRES/Portatil/Bass Model/IJF/CodeRevision/Forecast0BlackBerry.csv")
# 
# ########################################################################
