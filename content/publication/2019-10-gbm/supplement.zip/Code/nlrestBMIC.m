function[c,ceq]=nlrestBMIC(theta)
    ceq=theta(2)+theta(3)/(theta(3)+theta(4))+0.001;
    c = [];
end