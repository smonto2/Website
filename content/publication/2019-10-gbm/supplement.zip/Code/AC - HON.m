%HON: A hybrid approach of NLS and OLS (J. Hong and H. Koo and T. Kim, 2016)
%% Data preparation
data = readtable('RAC.csv');
dNt = data.Ss;
Nt = data.CumSs;
T = length(Nt);
m =Nt(T)*1.1:Nt(T)*0.001:Nt(T)*1.5;
t = 13;
RACEst = cumsum(data.Ss(1:t));
Yt = zeros(t,length(m));
Xt = zeros(t,length(m));
for i=1:length(m)
    for j=1:t
        if j==1
            Yt(j,i)=RACEst(j)/(m(i)-RACEst(j));
        else
            Yt(j,i)=(RACEst(j)-RACEst(j-1))/(m(i)-RACEst(j));
        end
        Xt(j,i)=RACEst(j)/m(i);
    end
end

%% Estimation
p0 = 0.0118;
q0 = 0.2959;
theta0 = [p0,q0];
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0,0];
ub = [1,1];
Results = zeros(length(m),4);
for i=1:length(m)
    f1 = @(theta)LinearOptHON(theta,Yt(:,i),Xt(:,i));
    [theta1,fval1] = fmincon(f1,theta0,A,b,Aeq,beq,lb,ub);
    Nth = zeros(T,1);
    Res2N = zeros(T,1);
    for j=1:T
       Nth(j,1) = m(i)*(1-exp(-(theta1(1)+theta1(2))*j))/(1+theta1(2)/theta1(1)*exp(-(theta1(1)+theta1(2))*j));
       Res2N(j,1) = (Nt(j)-Nth(j,1))^2;
    end
    SumRes2N = sum(Res2N(:,1));
    Results(i,:) = [SumRes2N,m(i),theta1];
end
[rowMin] = find(Results(:,1)==min(Results(:,1)));
Para = Results(rowMin,:);
NthMin = zeros(T,1);
dNthMin = zeros(T,1);
for i=1:T
    NthMin(i,1) = Para(2)*(1-exp(-(Para(3)+Para(4))*i))/(1+Para(4)/Para(3)*exp(-(Para(3)+Para(4))*i));
    if i==1
        dNthMin(i) = NthMin(i);
    else
        dNthMin(i) = NthMin(i)-NthMin(i-1);
    end    
end

ResAbsdNt = zeros(T,1);
Res2dNt = zeros(T,1);
ResAbsNt = zeros(T,1);
Res2Nt = zeros(T,1);
for i=1:T
    ResAbsdNt(i) = abs(dNt(i)-dNthMin(i));
    Res2dNt(i) = (dNt(i)-dNthMin(i))^2;
    ResAbsNt(i) = abs(Nt(i)-NthMin(i));
    Res2Nt(i) = (Nt(i)-NthMin(i))^2;   
end

sum(ResAbsdNt)/T
(sum(Res2dNt)/T)^0.5
sum(ResAbsNt)/T
(sum(Res2Nt)/T)^0.5

figure()
plot(Nt)
hold on
plot(NthMin)
hold off

figure()
plot(dNt)
hold on
plot(dNthMin)
hold off
