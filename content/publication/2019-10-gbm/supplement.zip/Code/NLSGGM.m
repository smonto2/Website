function[SumRes2]=NLSGGM(theta,Nt)
Resi2 = zeros(length(Nt),1);
Nth = zeros(length(Nt),1);
    for i=1:length(Resi2)
        Nth(i) = theta(1)*((1-exp(-(theta(2)+theta(3))*i))/(1+theta(3)/theta(2)*exp(-(theta(2)+theta(3))*i)))^0.5*(1-exp(-(theta(4)+theta(5))*i))/(1+theta(5)/theta(4)*exp(-(theta(4)+theta(5))*i));
        Resi2(i) = (Nt(i)-Nth(i))^2;
    end
    SumRes2 = sum(Resi2);
end