#
# Simulation exercise
#

remove(list = ls())
graphics.off()
require(mvtnorm)
require(R2jags)
# require(rgenoud)

# Commands independent of data amount
set.seed(10101)
betas <- c(-1.5, 1, -2.5)
p <- 0.01; q <- 0.4; m <- 20000
pobpars <- c(p, q, m, betas)

Time <- 25
unit <- 1:Time
x1 <- rnorm(Time, mean = 4000, sd = 25)
x2 <- rnorm(Time, mean = 1500, sd = 25)
x3 <- rnorm(Time, mean = 3000, sd = 25)
X <- rbind(0, cbind(log(x1/x1[1]), log(x2/x2[1]), log(x3/x3[1])))
xdata <- c(unit + X[-1, ]%*%betas)
Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
Ss <- m*(diff(Ft)) + rnorm(Time, mean = 0, sd = 1)
datos <- data.frame(Ss = Ss, x1 = x1, x2 = x2, x3 = x3, unit = unit)

# Completing the necessary data
datos$Yt <- cumsum(datos$Ss)
datos$Yt2 <- datos$Yt^2

# Previous arbitrary markets
prev <- 3
params <- matrix(c(0.01, 0.02, 0.025, 0.35, 0.4, 0.5, 20000, 30000, 50000, -1.3, -1, -0.2, 1, 1.5, 3.5, -1, -4, -2.5), nrow = prev)
parnames <- c('p', 'q', 'm', 'b1', 'b2', 'b3')
colnames(params) <- parnames
scalemat <- diag(apply(params, 2, var))
locvec <- colMeans(params)


# Functions for estimating without covariates
formwoc <- formula(Ss ~ m*(((1 - exp(-unit*(p+q)))/(1 + (q/p)*exp(-unit*(p+q)))) - ((1 - exp(-(unit-1)*(p+q)))/(1 + (q/p)*exp(-(unit-1)*(p+q))))))
funwoc <- function(pars, y) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]
    Time <- length(y); unit <- 1:Time
    Ft <- c(0, (1 - exp(-unit*(p+q)))/(1 + (q/p)*exp(-unit*(p+q))))
    res <- sum((y - m*diff(Ft))^2)
    return(res)
}

# Functions for estimating with covariates
formwc <- formula(Ss ~ m*(((1 - exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit + XT[unit + 1, ]%*%b)*(p+q)))) - ((1 - exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q)))/(1 + (q/p)*exp(-(unit - 1 + XT[unit, ]%*%b)*(p+q))))))
funwc <- function(pars, y, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- length(y); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- sum((y - m*diff(Ft))^2)
    return(res)
}

# Function for Bayesian estimation
bass <- function() {
    # Likelihood
    for (i in 1:Time) {
        y[i] ~ dnorm(mu[i], tau)
        mu[i] <- m*(((1 - exp(-(unit[i] + b[1]*x1[i+1] + b[2]*x2[i+1] + b[3]*x3[i+1])*(p+q)))/(1 + (q/p)*exp(-(unit[i] + b[1]*x1[i+1] + b[2]*x2[i+1] + b[3]*x3[i+1])*(p+q)))) - ((1 - exp(-(unit[i] - 1 + b[1]*x1[i] + b[2]*x2[i] + b[3]*x3[i])*(p+q)))/(1 + (q/p)*exp(-(unit[i] - 1 + b[1]*x1[i] + b[2]*x2[i] + b[3]*x3[i])*(p+q)))))
    }

    # Priors
    tempvar ~ dbeta(1, 1)
    tau <- (1 / 2000) * tempvar/(1 - tempvar)
    sigma <- 1/sqrt(tau)
    p ~ dt(locvec[1],  1/scalemat[1, 1], 3)
    q ~ dt(locvec[2],  1/scalemat[2, 2], 3)
    m ~ dt(locvec[3],  1/scalemat[3, 3], 3)
    for (j in 1:3) {
        b[j] ~ dt(locvec[j], 1/scalemat[j, j], 3)
    }
}

# Function for fitted values without covariates
fittedbayeswoc <- function(pars, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- nrow(X); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- m*diff(Ft)
    return(res)
}

# Function for fitted values with covariates
fittedbayeswc <- function(pars, X) {
    p <- pars[1]; q <- pars[2]; m <- pars[3]; betas <- pars[4:6]
    Time <- nrow(X); unit <- 1:Time
    xdata <- c(unit + X%*%betas)
    Ft <- c(0, ((1 - exp(-xdata*(p+q)))/(1 + (q/p)*exp(-xdata*(p+q)))))
    res <- m*diff(Ft)
    return(res)
}


# Data amounts and results list
Tvec <- 0:25
reslist <- rep(list(NA), length(Tvec))
names(reslist) <- Tvec

for (i in 1:length(Tvec)) {
    Time <- Tvec[i]
    coefmat <- matrix(NA, nrow = length(parnames), ncol = 4)
    semat <- matrix(NA, nrow = length(parnames), ncol = 4)
    colnames(coefmat) <- colnames(semat) <- c('OLS', 'BM', 'GBM', 'Bayes')
    rownames(coefmat) <- rownames(semat) <- parnames
    if (Time != 0) {
        unit <- 1:Time
        datosT <- datos[unit, ]
        XT <- X[1:(Time + 1), ]
        datosT$Bayes <- datosT$GBM <- datosT$BM <- datosT$OLS <- NA
        # OLS regression for starting values
        ols <- lm(Ss ~ Yt + Yt2, data = datosT) # Three data points necessary
        a <- coef(ols)[3]; b <- coef(ols)[2]; c <- coef(ols)[1]
        a <- unname(a); b <- unname(b); c <- unname(c)
        mest <- (-b - sqrt(b^2 - 4*a*c))/(2*a)
        pest <- c/mest; qest <- -a*mest
        pars <- list(p = pest, q = qest, m = mest)
        parswc <- list(p = pest, q = qest, m = mest, b = rep(0, ncol(XT)))
        pars.v <- unlist(pars)
        pars.vwc <- unlist(parswc)

        # Estimation without covariates
        tryCatch({
            nlswoc <- nls(formula = formwoc, start = pars, data = datosT, algorithm = 'port', lower = c(0, 0, -Inf), upper = c(1, 1, Inf))
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})

        # nlminwoc <- nlminb(objective = funwoc, start = pars.v, y = datos$Ss, lower = c(0, 0, -Inf), upper = c(1, 1, Inf))
        # uncwoc <- optim(fn = funwoc, par = pars.v, y = datos$Ss, hessian = TRUE)
        # genwoc <- genoud(funwoc, nvars = 3, unit = unit, y = St, Domains = cbind(rep(0, 3), c(1, 1, 10000)), hessian = TRUE)

        # Estimation with covariates
#         tryCatch({
#             nlswc <- nls(formula = formwc, start = parswc, m = mest, data = datosT, algorithm = 'port', lower = c(0, 0, -Inf, rep(-Inf, ncol(XT))), upper = c(1, 1, Inf, rep(Inf, ncol(XT))))
#         }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})

        # nlminwc <- nlminb(objective = funwc, start = pars.vwc, y = datos$Ss, X = X[-1, ], lower = c(0, 0, -Inf, rep(-Inf, ncol(X))), upper = c(1, 1, Inf, rep(Inf, ncol(X))))
        # uncwc <- optim(fn = funwc, par = pars.vwc, y = datos$Ss, X = X[-1, ], hessian = TRUE)
        # genwc <- genoud(fn = funwc, nvars = 6, y = datos$Ss, X = X[-1, ], Domains = cbind(c(0, 0, -Inf, rep(-Inf, ncol(X))), c(1, 1, Inf, rep(Inf, ncol(X)))), hessian = TRUE, max.generations = 150)

        #
        # Bayesian estimation
        #

#         # Previous markets based on estimated information
#         prev <- 3
#         cmat <- summary(nlswc)$coefficients[ , 1:2]
#         params <- matrix(rnorm(n = prev*nrow(cmat), mean = cmat[ , 1], sd = cmat[ , 2]), nrow = prev, byrow = TRUE)
#
#         datos_list <- list(Time = Time, y = datos$Ss, x1 = X[ , 1], x2 = X[ , 2], x3 = X[ , 3], unit = unit, locvec = locvec, scalemat = scalemat)
#         monitor <- c('p', 'q', 'm', 'b', 'tau')
#
#         jagsfit <- jags(data = datos_list, inits = list(parswc), monitor, n.chains = 1,
#                         n.iter = 200000, model.file = bass, n.thin = 50)
#         chains <- as.mcmc(jagsfit)
#         summary(chains)
#         traceplot(chains)
#

        # Data case
        datos_list <- list(Time = Time, y = datosT$Ss, x1 = XT[ , 1],
                           x2 = XT[ , 2], x3 = XT[ , 3], unit = unit,
                           locvec = locvec, scalemat = scalemat)
        n.iter <- 400000
        n.burnin <- n.iter/2
        n.thin <- 50
        monitor <- c('p', 'q', 'm', 'b', 'tau')
        jagsfit <- jags(data = datos_list, inits = list(parswc), monitor, n.chains = 1,
                         n.iter = n.iter, n.burnin = n.burnin, n.thin = n.thin, model.file = bass)
        bayespars <- unlist(jagsfit$BUGSoutput$median[c('p', 'q', 'm', 'b')])
        bayesse <- unlist(jagsfit$BUGSoutput$sd[c('p', 'q', 'm', 'b')])
        bayesfit <- fittedbayeswc(bayespars, XT[-1, , drop = FALSE])
        temp <- jagsfit$BUGSoutput$sims.matrix[ , c('p', 'q', 'm', 'b[1]', 'b[2]', 'b[3]')]

        # Saving results
        coefmat[1:3, 'OLS'] <- c(pest, qest, mest)

        tryCatch({
            coefmat[1:3, 'BM'] <- coef(nlswoc)
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        tryCatch({
            coefmat[ , 'GBM'] <- coef(nlswc)
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        coefmat[ , 'Bayes'] <- bayespars

        # semat[1:3, 'OLS'] <- c(pest, qest, mest)
        tryCatch({
            semat[1:3, 'BM'] <- summary(nlswoc)$coefficients[, 'Std. Error']
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        tryCatch({
            semat[, 'GBM'] <- summary(nlswc)$coefficients[, 'Std. Error']
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        semat[ , 'Bayes'] <- bayesse

        # Fitted values
        datosT$OLS <- ols$fitted.values
        tryCatch({
            datosT$BM <- fitted(nlswoc)
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        tryCatch({
            datosT$GBM <- fitted(nlswc)
        }, error = function(e) {cat("ERROR :", conditionMessage(e), "\n")})
        datosT$Bayes <- bayesfit

        # Diagnostic results
        autoc <- autocorr.diag(as.mcmc(temp)) #, lags = 1:36)
        heidel <- heidel.diag(as.mcmc(temp))
        geweke <- geweke.diag(as.mcmc(temp))
        raftery <- raftery.diag(as.mcmc(temp))

        # Chain results
        reslist[[i]] <- list(Coefficients = coefmat, 'Std. Errors' = semat,
                               Data = datosT[ , c('Ss', 'OLS', 'BM', 'GBM', 'BM')],
                               Chains = temp, Diag = list(Autocorrelation = autoc,
                                Heidelberger = heidel, Geweke = geweke, Raftery = raftery))
    } else {
        # No data case
        temp <- rmvnorm(1e3, mean = locvec, sigma = scalemat)
        bayespars <- apply(temp, 2, median)
        bayesse <- apply(temp, 2, sd)

        # Saving results
        colnames(temp) <- parnames
        coefmat[ , 'Bayes'] <- bayespars
        semat[ , 'Bayes'] <- bayesse
        reslist[[i]] <- list(Coefficients = coefmat, 'Std. Errors' = semat,
                               Data = NA, Chains = temp)
    }
}

# Forecast matrix
fittedmat <- sapply(1:length(Tvec), function(n) cumsum(fittedbayeswc(reslist[[n]]$Coefficients[1:6, 'Bayes'], X[-1, ])))

# Cumulative forecast plots
reppoints <- c(0, 5, 10, 25)
setEPS()
postscript('C:/Users/SantiagoM/Google Drive/Estudio/Bass/Tex/FEx1.eps')
plot(datos$Yt, type = 'l', main = 'Cumulative Sales', xlab = 'Years', ylab = 'Sales',
     ylim = c(0, max(fittedmat)))
sapply(1:length(Tvec), function(n) lines(fittedmat[ , n], col = 1 + n, lty = 2))
legend(x = 'topleft', legend = c('Simulated', paste(reppoints, 'data points')),
       col = c(1, reppoints + 2), lty = c(1, rep(2, length(reppoints))))
dev.off()

# #
# # Adaptative plots
# #
# 
# # Data matrices and plot limits
# zmatx <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$x)
# zmaty <- sapply(1:6, function(i) density(reslist$`0`$Chains[ , i])$y)
# zlimx <- rbind(apply(zmatx, 2, min), apply(zmatx, 2, max))
# zlimy <- rbind(apply(zmaty, 2, min), apply(zmaty, 2, max))
# 
# densize <- length(density(reslist[[2]]$Chains[ , 1])$x)
# tmatx <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tmaty <- matrix(NA, nrow = densize*(length(Tvec) - 1), ncol = 6)
# tlimx <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
# tlimy <- matrix(NA, nrow = 2*(length(Tvec) - 1), ncol = 6)
# 
# for (j in 1:6) {
#     for (i in 1:(length(Tvec) - 1)) {
#         tmatx[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$x
#         tmaty[(densize*(i - 1) + 1):(densize*i), j] <- density(reslist[[i + 1]]$Chains[ , j])$y
#         tlimx[(2*i - 1):(2*i), j] <- c(min(tmatx[(densize*(i - 1) + 1):(densize*i), j]), max(tmatx[(densize*(i - 1) + 1):(densize*i), j]))
#         tlimy[(2*i - 1):(2*i), j] <- c(min(tmaty[(densize*(i - 1) + 1):(densize*i), j]), max(tmaty[(densize*(i - 1) + 1):(densize*i), j]))
#     }
# }
# 
# # Plots
# for (j in 1:3) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = paste('Prior and posterior distributions for', parnames[j]),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }
# 
# for (j in 4:6) {
#     dev.new()
#     plot(zmatx[ , j], zmaty[ , j], type = 'l', main = substitute(paste(x, beta[n]), env = list(x = 'Prior and posterior distributions for ', n = j - 3)),
#          xlab = 'Parameter Space', ylab = 'Density', xlim = c(min(c(zlimx[ , j], tlimx[ , j])), max(c(zlimx[ , j], tlimx[ , j])))
#          # ylim = c(min(c(zlimy[ , j], tlimy[ , j])), max(c(zlimy[ , j], tlimy[ , j])))
#          )
#     for (i in 1:(length(Tvec) - 1)) {
#         lines(tmatx[(densize*(i - 1) + 1):(densize*i), j], tmaty[(densize*(i - 1) + 1):(densize*i), j], col = i + 1)
#     }
#     abline(v = pobpars[j], lty = 2)
# #     legend(x = 'topleft', legend = c('Prior', paste(Tvec[-1], 'data points')),
# #            col = c(1, 2:length(Tvec)), lty = 1)
# }

#
# Mean Errors
#

msefit <- sapply(1:length(Tvec), function(n) mean((c(fittedmat[1, n], diff(fittedmat[ , n])) - datos$Ss)^2))
maefit <- sapply(1:length(Tvec), function(n) mean(abs(c(fittedmat[1, n], diff(fittedmat[ , n])) - datos$Ss)))
msecumfit <- sapply(1:length(Tvec), function(n) mean((fittedmat[ , n] - datos$Yt)^2))
maecumfit <- sapply(1:length(Tvec), function(n) mean(abs(fittedmat[ , n] - datos$Yt)))

# One step-ahead forecast
osaf <- diag(fittedmat[,-length(Tvec)])
(osaf - datos$Yt)^2
