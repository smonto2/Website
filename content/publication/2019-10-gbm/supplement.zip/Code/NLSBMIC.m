function[SumRes2]=NLSBMIC(theta,Nt)
Resi2 = zeros(length(Nt),1);
Nth = zeros(length(Nt),1);
    for i=1:length(Resi2)
        Nth(i) = theta(1)*((theta(2)*(theta(3)+theta(4))+theta(3)*exp(-(theta(3)+theta(4))*i))/(theta(2)*(theta(3)+theta(4))-theta(4)*exp(-(theta(3)+theta(4))*i)));
        Resi2(i) = (Nt(i)-Nth(i))^2;
    end
    SumRes2 = sum(Resi2);
end