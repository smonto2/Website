# Generalized Bass Model data simulation

#
# Simulation exercise
#

remove(list = ls())
require(mvtnorm)

# Commands independent of data amount
set.seed(10101)
betas <- c(-1.5, 1, -2.5)
p <- 0.01; q <- 0.4; prop <- 0.4; M <- 50000; m <- prop*M
pobpars <- c(p, q, m, betas)

Time <- 25
tt <- 0:Time
x1 <- rnorm(Time, mean = 4000, sd = 100)
x2 <- rnorm(Time, mean = 1500, sd = 25)
x3 <- rnorm(Time, mean = 3000, sd = 50)
covars <- cbind(x1, x2, x3)
X <- rbind(0, apply(covars, 2, function(x) log(x/x[1])))
k <- ncol(X)
Xt <- c(tt + X%*%betas)
Ft <- (1 - exp(-(p + q)*Xt))/(1 + (q/p)*exp(-(p + q)*Xt))
Ss <- m*(diff(Ft)) + rnorm(Time, mean = 0, sd = 1)
datos <- data.frame(Ss = Ss, x1 = x1, x2 = x2, x3 = x3)

# Completing the necessary data for OLS
datos$Nt <- c(0, cumsum(datos$Ss[-Time]))
datos$Nt2 <- datos$Nt^2
datos$tt <- 1:Time

write.csv(datos, file = 'C:/Users/SantiagoM/Google Drive/Estudio/Bass/Datos/Simulation.csv',
          row.names = FALSE)
