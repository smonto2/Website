function[SumRes2]=LinearOptHON(theta,Yt,Xt)
Resi2 = zeros(length(Yt),1);
Ythat = zeros(length(Yt),1);
    for i=1:length(Resi2)
        Ythat(i) = theta(1)+theta(2)*Xt(i);
        Resi2(i) = (Yt(i)-Ythat(i))^2;
    end
    SumRes2 = sum(Resi2);
end