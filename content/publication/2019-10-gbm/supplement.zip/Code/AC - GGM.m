%GGM: Guseo & Guidolin, 2009

%% GGM: Dryer
dataDry = readtable('DryNew.csv');
dNt = dataDry.Ss;
Nt = cumsum(dNt);
T = length(Nt);
p0 = 0.0118;
q0 = 0.2959;
m0 = 12554;
theta0 = [m0,p0,q0,p0,q0];
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0,0,0,0,0];
ub = [20000,5,5,1,1];
f1 = @(theta)NLSGGM(theta,Nt);
[theta] = fmincon(f1,theta0,A,b,Aeq,beq,lb,ub);
Nth = zeros(length(Nt),1);
dNth = zeros(length(Nt),1);
for i=1:T
    Nth(i) = theta(1)*((1-exp(-(theta(2)+theta(3))*i))/(1+theta(3)/theta(2)*exp(-(theta(2)+theta(3))*i)))^0.5*(1-exp(-(theta(4)+theta(5))*i))/(1+theta(5)/theta(4)*exp(-(theta(4)+theta(5))*i));
    if i==1
        dNth(i) = Nth(i);
    else
        dNth(i) = Nth(i)-Nth(i-1);
    end
end

figure()
plot(Nt)
hold on
plot(Nth)
hold off

figure()
plot(dNt)
hold on
plot(dNth)
hold off

%% GGM: Room air conditioner
dataRAC = readtable('RAC.csv');
dNt = dataRAC.Ss;
Nt = cumsum(dNt);
T = length(Nt);
theta0 = [Nt(T)*1.5,theta(2),theta(3),theta(4),theta(5)];
t = 13;
RACEst = cumsum(dataRAC.Ss(1:t));
f1 = @(theta)NLSGGM(theta,RACEst);
[thetaRAC] = fmincon(f1,theta0,A,b,Aeq,beq,lb,ub);
Nth = zeros(length(Nt),1);
dNth = zeros(length(Nt),1);
for i=1:T
    Nth(i) = thetaRAC(1)*((1-exp(-(thetaRAC(2)+thetaRAC(3))*i))/(1+thetaRAC(3)/thetaRAC(2)*exp(-(thetaRAC(2)+thetaRAC(3))*i)))^0.5*(1-exp(-(thetaRAC(4)+thetaRAC(5))*i))/(1+thetaRAC(5)/thetaRAC(4)*exp(-(thetaRAC(4)+thetaRAC(5))*i));
    if i==1
        dNth(i) = Nth(i);
    else
        dNth(i) = Nth(i)-Nth(i-1);
    end
end

ResAbsdNt = zeros(T,1);
Res2dNt = zeros(T,1);
ResAbsNt = zeros(T,1);
Res2Nt = zeros(T,1);
for i=1:T
    ResAbsdNt(i) = abs(dNt(i)-dNth(i));
    Res2dNt(i) = (dNt(i)-dNth(i))^2;
    ResAbsNt(i) = abs(Nt(i)-Nth(i));
    Res2Nt(i) = (Nt(i)-Nth(i))^2;   
end

sum(ResAbsdNt)/T
(sum(Res2dNt)/T)^0.5
sum(ResAbsNt)/T
(sum(Res2Nt)/T)^0.5

figure()
plot(Nt)
hold on
plot(Nth)
hold off

figure()
plot(dNt)
hold on
plot(dNth)
hold off


    
