function [beta_save] = BayesianLogistic(y,X,tausq)
%==========================================================================
%=============================| PRELIMINARIES |============================

[~,k] = size(X);

% Input values for the MCMC algorithm
burnin = 5000;
nsave = 10000;
niter = burnin + nsave;

% Set prior hyperparameters
B0 = 1000*eye(k,k);
b0 = zeros(k,1);

% Initialize parameters
[betaMLE,H] = MleLogistic(X, y, 1000); % MLE estimates

beta = zeros(k,1);

% Create objects to be filled in main simulation loop
beta_draws = zeros(niter,k);

% Set up quantities for M-H algorithm
% tausq = 1;
Omega = tausq*1./(-H + 1./B0);
count = 0;

%==========================================================================
%======================| MCMC MAIN LOOP START HERE |=======================

for iter = 1:niter

    % (i) Draw a candidate
    beta_cnd =  betaMLE + chol(Omega)*randn(k,1);


    % (ii) Calculate acceptance probability
    log_lik_ratio = y'*log(sigmoid(X*beta)) + (1-y)'*log(1-sigmoid(X*beta)) - ...
        y'*log(sigmoid(X*beta_cnd)) - (1-y)'*log(1-sigmoid(X*beta_cnd));
    log_prior_ratio = -0.5*(beta-b0)'/B0*(beta-b0) + ...
        0.5*(beta_cnd-b0)'/B0*(beta_cnd-b0);
    log_propose_ratio = -0.5*(beta-betaMLE)'/Omega*(beta-betaMLE) + ...
        0.5*(beta_cnd-betaMLE)'/Omega*(beta_cnd-betaMLE);
    log_ar = log_lik_ratio + log_prior_ratio - log_propose_ratio;
    
    prop = min(1,exp(log_ar));

    % (iii) Accept candidate draw with probability alpha_rw
    if rand <= prop
        beta = beta_cnd;
        count = count + 1;
    end

    % Save draws
    beta_draws(iter,:) = beta;
end

beta_save = beta_draws(burnin+1:niter,:);
accrate = count/niter;
beta_mean = mean(beta_save,1)';
end

function s = sigmoid(z)
    s = 1 ./ (1 + exp(-z));
end