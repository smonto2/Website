function [beta_save] = BayesianProbit(y,X)
%==========================================================================
%=============================| PRELIMINARIES |============================

[n,k] = size(X);

% Input values for the MCMC algorithm
burnin = 2000;
nsave = 10000;
niter = burnin + nsave;

% Set prior hyperparameters
B0 = eye(k);
b0 = zeros(k,1);

% Initialize parameters
beta = zeros(k,1);
ystar = zeros(n,1);

% Create objects to be filled in main simulation loop
beta_draws = zeros(niter,k);

% Compute posterior covariance (fixed across iterations)
B_bar = inv(X'*X + inv(B0)); % Proper covariance update

%==========================================================================
%=====================| GIBBS MAIN LOOP START HERE |=======================

for iter = 1:niter
    % 1. Update ystar (latent variable)
    mean_ystar = X * beta;
    ystar(y==1) = truncnorm_rnd(mean_ystar(y==1), 1, 0, Inf); 
    ystar(y==0) = truncnorm_rnd(mean_ystar(y==0), 1, -Inf, 0); 

    % 2. Update beta
    b_bar = B_bar * (X'*ystar + inv(B0)* b0); % Proper mean update
    beta = b_bar + chol(B_bar, 'lower') * randn(k,1);
    
    % Save draws
    beta_draws(iter,:) = beta;
end

% Save only post-burnin samples
beta_save = beta_draws(burnin+1:end,:);
end

function sample = truncnorm_rnd(mu, sigma2, left, right)
% Generates a random sample from a normal distribution truncated to (left, right)
% using Inverse transform sampling

std_dev = sqrt(sigma2);
if isinf(left) && ~isinf(right)
    % (-Inf, right) truncation
    upperProb = normcdf((right - mu) ./ std_dev);
    u = upperProb .* rand(size(mu));
elseif ~isinf(left) && isinf(right)
    % (left, Inf) truncation
    lowerProb = normcdf((left - mu) ./ std_dev);
    u = lowerProb + (1 - lowerProb) .* rand(size(mu));
else
    % (left, right) truncation
    lowerProb = normcdf((left - mu) ./ std_dev);
    upperProb = normcdf((right - mu) ./ std_dev);
    u = lowerProb + (upperProb - lowerProb) .* rand(size(mu));
end

% Ensure numerical stability
u = min(max(u, 1e-10), 1 - 1e-10);

% Compute inverse CDF (quantile function)
sample = mu + sqrt(2) * std_dev .* erfinv(2 * u - 1) ;
end
