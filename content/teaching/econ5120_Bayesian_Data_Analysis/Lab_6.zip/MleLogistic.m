function [beta,Hessian] = MleLogistic(X, y, max_iter)
% Logistic_regression_newton

    % Initialize beta
    beta = zeros(size(X,2), 1);

    % Iterative Newton-Raphson
    for iter = 1:max_iter+1
        % Compute predictions
        p = sigmoid(X * beta);
        
        % Compute gradient
        gradient = X' * (y - p);
        
        % Compute Hessian
        D = diag(p .* (1 - p));
        Hessian = -X' * D * X;
        
        if iter <= max_iter
            % Update beta using Newton-Raphson
            beta = beta - Hessian \ gradient;
        end
    end
end    

function s = sigmoid(z)
    s = 1 ./ (1 + exp(-z));
end

