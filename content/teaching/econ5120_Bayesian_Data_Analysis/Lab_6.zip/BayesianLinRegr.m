function [b_final,s2_final] = BayesianLinRegr(y,X)
% BayesianLinRegr: Gibbs Sampler for Bayesian Linear Regression 
% with Independent Priors
%
% Inputs:
%   y - Response variable (n x 1)
%   X - Regressors (n x k)

[n,k] = size(X);

% Input values for the MCMC algorithm
burnin = 2500;
niter = 10000;
nsim = burnin + niter + 1;

% Prior hyperparameters
b_underbar = zeros(k, 1);
B_underbar = 1000*eye(k);
a_underbar = 0.02;
d_underbar = 0.02;

% Create objects to be filled in main simulation loop
b_gibbs = zeros(nsim, k);
s2_gibbs = ones(nsim, 1); % This sets the initial value sigma^2(0) = 1
keep = (burnin + 2):nsim; % Iterations to keep

% Posterior hyperparameters (do not change within main simulation loop)
a_bar = a_underbar + n;
B_underbari = inv(B_underbar); % Precompute the inverse of B_underbar for efficiency

%% Main simulation loop
for s = 2:nsim
    % Draw betas (we need to compute b_bar and B_bar)
    B_bar = inv((X'*X ./ s2_gibbs(s-1)) + B_underbari);
    b_bar = B_bar*((X'*y ./ s2_gibbs(s-1)) + B_underbari*b_underbar);
    b_gibbs(s, :) = mvnrnd(b_bar, B_bar); % Draw from multivariate normal

    % Draw sigma^2 (we need a_bar and d_bar)
    d_bar = d_underbar + (y - X*b_gibbs(s, :)')'*(y - X*b_gibbs(s, :)');
    s2_gibbs(s) = invgamrnd(a_bar/2, d_bar/2, 1, 1); % Draw from inverse-gamma
end

%% Summary of posteriors
% Keep final objects
b_final = b_gibbs(keep, :);
s2_final = s2_gibbs(keep);

% Posterior means, medians and standard deviations
b_means = mean(b_final)';
b_medians = median(b_final)';
b_sds = std(b_final)';
s2_mean = mean(s2_final);
s2_median = median(s2_final);
s2_sd = std(s2_final);

end