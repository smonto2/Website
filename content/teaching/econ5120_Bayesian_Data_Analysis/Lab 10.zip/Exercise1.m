% Code to demonstrate construction of VAR based on three equivalent representations of a VAR model

addpath('functions')

% Generate M variables of length T randomly
T = 10;             % Number of observations
M = 3;              % Number of endogenous variables
p = 2;              % p is the number of lags

Y = randn(T,M);     % Our dependent variables

% First obtain the matrix of lags of Y
Ylag = mlag2(Y,p);           %these are the lags of Y
Ylag1=Y(1:end-1,:);
Ylag2=Y(1:end-2,:);


% Generate X, Z, W (Note: first p rows are lost from taking lags)
X = [ones(T-p,1) Ylag(p+1:T,:)];
[Z,K] = create_RHS(Ylag(p+1:end,:),M,p,T);
W = kron(eye(M),X);

Y=Y(p+1:end,:);%correct for the p lags 

beta_OLS= (X'*X)\(X'*Y);
beta_OLS2=(W'*W)\(W'*Y(:));
beta_OLS
reshape(beta_OLS2,1+M*p,M)


Yp=Y';
beta_OLS3=(Z'*Z)\(Z'*Yp(:));
%check that beta_OLS3 also gives same estimates



clc;
disp('Type "X", "Z", and "W" in the command window to print the respective matrices')
disp('It would be useful to keep T and M and p at low values so that the big matrices can be printed easily')


