function [beta_final,sigma2_final,elbo_chain,b_bar_chain] = VBRegr(y,X,burnin,niter,prior)
% VBRegr: Gibbs Sampler for Bayesian Linear Regression 
% with Independent Priors
%
% INPUT:
%
%
% OUTPUT:

%==========================================================================
%============================| PRELIMINARIES |=============================

[n,p] = size(X);

% Input values for prior hyperparameters ====
if exist("prior")
    a_underbar = prior.a;
    d_underbar = prior.d;
else
    a_underbar = 0.02;
    d_underbar = 0.02;
end
B_underbar = 1000*eye(p);
b_underbar = zeros(p, 1);
% Initial values of parameters 
a_bar = 0.02;
d_bar = 0.02;

% Input values fitting loop ====
maxiter = 1000; % Maximum number of iterations
tolerance = 1e-4;
% Monitor convergence
elbo0 = -inf; % Initial values of Evidence Lower Bound (elbo)
elbo1 = 0;
tau = abs(elbo1-elbo0); % Convergence test quantity

% Input values for main simulation loop ====
burnin = 2500;
niter = 10000;
nsim = burnin + niter + 1; 

% Create objects to be filled in fitting loop ====
elbo_chain = [elbo0];
b_bar_chain = [];

% Create objects to be filled in main simulation loop ====
beta_sim = zeros(nsim,p);
sigma2_sim = ones(nsim,1);
keep = (burnin + 2):nsim; % Iterations to keep

% Convenient quantity ====
B_underbari = inv(B_underbar);

%==========================================================================
%========================| FITTING LOOP GOES FIRST |=======================
% The following implements the iterative updating of variational parameters 
% until the ELBO has converged.

iter = 1;

while (tau>tolerance) & (iter<=maxiter)

    % Compute the expectations w.r.t. q(sigma2)
    Esigma2 = a_bar/d_bar;

    % Update posterior hyperparameters for beta
    B_bar = inv(Esigma2*(X'*X) + B_underbari);
    b_bar = B_bar*(Esigma2*(X'*y) + B_underbari*b_underbar);

    % Compute the expectations w.r.t. q(beta)
    Ebeta = trace(B_bar*(X'*X)) + sum((y-X*b_bar).^2);

    % Update posterior hyperparameters for sigma2
    a_bar = a_underbar+n;
    d_bar = d_underbar+Ebeta;

    % Compute Evidence Lower Bound
    Q1 = n/2*(psi(a_bar/2)-log(d_bar/2)) - n/2*log(2*pi) + ...
        - (a_bar/(2*d_bar))*( trace(B_bar*(X'*X)) + sum((y-X*b_bar).^2) );
    Q2 = -p/2*log(2*pi) - 1/2*log(det(B_underbari)) + ...
        - 1/2*( trace(B_bar*B_underbari) + (b_bar-b_underbar)'*B_underbari*(b_bar-b_underbar) );
    Q3 = a_underbar/2*log(d_underbar/2) - gammaln(a_underbar/2) + ...
        + (a_underbar/2+1)*( psi(a_bar/2) - log(d_bar/2) ) - (d_underbar*a_bar)/(2*d_bar);
    Q4 = -(p/2)*(1+log(2*pi)) - 1/2*log(det(B_bar));
    Q5 = (a_bar/2+1)*psi(a_bar/2) - a_bar/2 -gammaln(a_bar/2) - log(d_bar/2);

    elbo1 = Q1+Q2+Q3-Q4-Q5;

    % Update test quantity
    tau = abs(elbo1-elbo0); 
    elbo0 = elbo1;
    iter=iter+1;

    elbo_chain = [elbo_chain,elbo0];
    b_bar_chain = [b_bar_chain,b_bar];

end
% disp(['Fitting loop ends after ' num2str(iter) ' iterations.'])

%==========================================================================
%========================| MAIN SIMULATION LOOP |==========================

for s = 2:nsim
    beta_sim(s,:) = mvnrnd(b_bar,B_bar); % Draw from multivariate normal
    sigma2_sim(s,:) = invgamrnd(a_bar/2,d_bar/2,1,1); % Draw from inverse-gamma
end

%==========================================================================
%===============================| SUMMARY |================================
%% Summary of posteriors
% Keep final objects
beta_final = beta_sim(keep, :);
sigma2_final = sigma2_sim(keep);

end