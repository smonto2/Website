function y = Draw_Gamma(a,b)
% Generate Gamma random draws
% this code is written with Gamma parameterized in terms of shape and inverse scale
y = gamrnd(a,1/b);
