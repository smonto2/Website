function [bmean,b2mo,bsd,taumean] = GibbsLasso(y,X)
%==========================================================================
%=============================| PRELIMINARIES |============================
[n,p] = size(X);

% Input values for the MCMC algorithm
nsave = 1000;
burnin = 100;
niter = burnin + nsave;

% Set prior hyperparameters
%this code is written with Gamma parameterized in terms of shape and inverse scale
% lambda2 ~ Gamma(r,d)
%These prior hyperparameter choices are not identical to those in the
%handout so your results with them may differ a bit
%You may want to experiment with these to investigate prior sensitivity
r = 1;
delta =1;

% Initialize parameters

% Get OLS quanities from the full model (only if sample size is large enough)
if n>p
    beta_OLS = inv(X'*X)*(X'*y);
    SSE_OLS = (y - X*beta_OLS)'*(y - X*beta_OLS);
    sigma2_OLS = SSE_OLS/(n-(p-1));
    b_cov = sigma2_OLS*inv(X'*X);
    b_sd = sqrt(diag(b_cov));
end

% Initialize parameters
beta = 0*ones(p,1); 
tau2 = 4*ones(p,1);
V_L = diag(tau2);
lambda2 = 1;
sigma2 = 0.001;
if n>p
    beta = beta_OLS;
    lambda2=(p*sqrt(sigma2_OLS)/(sum(abs(beta_OLS)))).^2;
    sigma2=sigma2_OLS;
end

%==========================================================================
%=====================| GIBBS MAIN LOOP START HERE |=======================
for iter = 1:niter
   if mod(iter,500)==0
        disp(iter)
    end
    
    % 1. Update beta from Normal
    A = inv(X'*X + inv(V_L));
    post_mean_beta = A*X'*y;
    post_var_beta = sigma2*A;
    beta = Draw_Normal(post_mean_beta,post_var_beta);
    
    % 2. Update tau2_j from Inverse Gaussian
    for j = 1:p
        a1 = (lambda2*sigma2)./(beta(j,1)^2);
        a2 = lambda2;
        tau2_inverse = Draw_IG(sqrt(a1),a2);
        tau2(j,1) = 1/tau2_inverse + 1e-15;  %note: often need to add a very small constant to avoid matrix singulariry
    end
    
    % Now that we have the new estimate of tau2, update V_L (the prior
    % covariance matrix of beta)
      V_L = diag(tau2);
    
    % 3. Update lambda2 from Gamma
    b1 = p + r;
    b2 = 0.5*sum(tau2) + delta;
    lambda2 = Draw_Gamma(b1,b2);
       
    % 4. Update sigma2 from Inverse Gamma
    c1 = (n-1+p)/2;
    PSI = (y-X*beta)'*(y-X*beta);
    c2 = 0.5*PSI + 0.5*(beta'/V_L)*beta;  
    sigma2 = Draw_iGamma(c1,c2);
 
    % Save draws
    if iter > burnin
        beta_draws(iter-burnin,:) = beta;
        tau2_draws(iter-burnin,:) = tau2;
        lambda2_draws(iter-burnin,:) = lambda2;
        sigma2_draws(iter-burnin,:) = sigma2;
    end
end 

%% Summary of posteriors
bmean =mean(beta_draws)';
b2mo = mean(beta_draws.^2)';
bsd = sqrt(b2mo - bmean.^2);
taumean = mean(sqrt(tau2_draws),1)';  

end