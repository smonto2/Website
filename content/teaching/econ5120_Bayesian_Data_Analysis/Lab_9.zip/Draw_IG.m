function y = Draw_IG(mu,lambda)
% Generate a draw from the Inverse Gaussian (Wald) distribution
%----------------------------------------------------------------
% This method is from
% John R. Michael, William R. Schucany, and Roy W. Haas (1976) Generating 
% Random Variates Using Transformations with Multiple Roots. The American 
% Statistician 30: 88-90.
%
% Written by Dimitris Korobilis
% Universite Catholique de Louvain
% 23 October 2010

% Modified by Santiago Montoya
% Previous version had "if rand > p1_v0" as the acceptance-rejection condition
% This lead to an incorrect probability of selecting the first root and invalid sampling
% Direction of inequality was corrected and file now outputs IG draws correctly
% University of Glasgow
% March, 2024

% First generate a chi_square(1) variate
v0 = randn.^2;

% Now find the first root in Eq. (5) of the paper
x1 = mu + (.5*(mu.^2)*v0)/lambda - (.5*mu/lambda)*sqrt(4*mu*lambda*v0 + (mu.^2)*(v0.^2));

% Accept x1 with probability p1_v0, otherwise accept x2
p1_v0 = mu/(mu+x1);
if rand <= p1_v0
    y = x1;
else
    % Only need to calculate second root if first rejected
    x2 = (mu.^2)/x1;
    y = x2;
end