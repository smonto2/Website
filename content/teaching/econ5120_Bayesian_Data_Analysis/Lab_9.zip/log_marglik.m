% lprobold=log marginal likelihood of the given model Eq (16.12)
% X and k are model specific 

function lprobold=log_marglik(y, X,k,n,g1,g2)

yty = (y-mean(y))'*(y-mean(y));
xtxinv=inv(X'*X);
ymy = y'*y - y'*X*xtxinv*X'*y;
lprobold = .5*k*log(g1) -.5*(n-1)*log(g2*ymy + g1*yty);

end 