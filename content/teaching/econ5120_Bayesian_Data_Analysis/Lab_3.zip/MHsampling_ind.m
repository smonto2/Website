function [thmean_ind,thvar_ind,accrate_ind] = MHsampling_ind(d)
% Independent MH
% d: Standard deviation of independent proposal

% Set up quantities and final objects to fill-in
burnin = 100;
niter = 10000;
nsim = burnin + niter;
theta_ind = zeros(niter, 1);

% Set initial value
thdraw_ind = 1;

% Count the number of accepted draws
count_ind = 0;

% Main simulation loop
for s = 1:nsim
    
    % Independent MH
    % (i) Draw a candidate
    thcand_ind = normrnd(0, d);
    % (ii) Calculate acceptance probability
    alpha_ind = min(exp(0.5*(abs(thdraw_ind) - abs(thcand_ind) + (thcand_ind/d)^2 - (thdraw_ind/d)^2)), 1);
    % (iii) Accept candidate draw with probability alpha_ind
    U = rand;
    if U <= alpha_ind
        thdraw_ind = thcand_ind;
        count_ind = count_ind + 1;
    end
    
    % Discard burnin draws
    if s > burnin
        keep = s - burnin;
        theta_ind(keep) = thdraw_ind;
    end
end
accrate_ind = count_ind/nsim; % Proportion of accepted candidate draws
thmean_ind = mean(theta_ind);
thvar_ind = var(theta_ind);
end