function [thmean_rw,thvar_rw,accrate_rw] = MHsampling_rw(c)
% Random-walk MH
% c: Standard deviation of random walk (RW) proposal

% Set up quantities and final objects to fill-in
burnin = 100;
niter = 10000;
nsim = burnin + niter;
theta_rw = zeros(niter, 1);

% Set initial value
thdraw_rw = 1;

% Count the number of accepted draws
count_rw = 0;

% Main simulation loop
for s = 1:nsim
    
    % Random-walk MH
    % (i) Draw a candidate
    thcand_rw = normrnd(thdraw_rw, c);
    % (ii) Calculate acceptance probability
    alpha_rw = min(exp(0.5*(abs(thdraw_rw) - abs(thcand_rw))), 1);
    % (iii) Accept candidate draw with probability alpha_rw
    U = rand;
    if U <= alpha_rw
        thdraw_rw = thcand_rw;
        count_rw = count_rw + 1;
    end
    
    % Discard burnin draws
    if s > burnin
        keep = s - burnin;
        theta_rw(keep) = thdraw_rw;
    end
end
accrate_rw = count_rw/nsim; % Proportion of accepted candidate draws
thmean_rw = mean(theta_rw);
thvar_rw = var(theta_rw);
end