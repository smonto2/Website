function [theta_new, prob_jump, accept] = HMC_iteration(theta_current, M, L, epsilon, Mu, Sigma)
    % HMC_ITERATION Perform one iteration of the Hamiltonian Monte Carlo algorithm.
    %
    % Inputs:
    %   theta_current - Current value of parameters (from previous draw) (a.k.a position)
    %   M             - Mass matrix
    %   L             - Number of leapfrog steps
    %   epsilon       - Step size for leapfrog steps
    %   Mu            - Mean of the target distribution
    %   Sigma         - Covariance matrix of the target distribution
    %
    % Outputs:
    %   theta_new     - New value of parameters after the iteration
    %   prob_jump     - Probability of accepting the new parameters
    %   accept        - Indicator of whether the new parameters were accepted (1) or not (0)

    k = length(theta_current);

    % Generate initial momentum
    phi0 = mvnrnd(zeros(k, 1), M)';

    % Use current position and initial momentum at start of trajectory
    phi = phi0;
    theta_cnd = theta_current;

    %% ==== Leapfrog method to update the proposal (phi,theta_cnd) ====
    % Make a half-step update for momentum at the beginning
    phi = phi - 0.5 * epsilon * gradlogpdfNormal(theta_cnd, Mu, Sigma);

    % Alternately update position and momentum
    for l = 1:L
        % Update position (full steps)
        theta_cnd = theta_cnd + epsilon * (M \ phi);
        
        % Update momentum
        if l < L
            q = 1; % Full steps except at end of trajectory
        else
            q = 0.5; % Half step at the end
        end
        phi = phi - q * epsilon * gradlogpdfNormal(theta_cnd, Mu, Sigma);
    end

    % Negate momentum at end of trajectory to make the proposal symmetric
    phi = -phi;

    %% ==== Metropolis step ====
    % Evaluate Hamiltonian at start and end of trajectory to calculate
    % acceptance probability
   
    H_current = logpdfNormal(theta_current, Mu, Sigma) - 0.5 * phi0' * (M \ phi0); % current Hamiltonian
    H_proposed = logpdfNormal(theta_cnd, Mu, Sigma) - 0.5 * phi' * (M \ phi); % proposed Hamiltonian
    r = exp(H_proposed - H_current);
    prob_jump = min(r, 1); % acceptance probability

    % Accept or reject the state at end of trajectory, returning either
    % the position at the end of the trajectory or the initial position
    U = rand(1); % a draw from Uniform(0,1);

    if prob_jump > U
        theta_new = theta_cnd;
        accept = 1;
    else
        theta_new = theta_current;
        accept = 0;
    end
end