function [lpdf,glpdf] = normalDistGrad(theta,Mu,Sigma)
    Z = theta - Mu;
    lpdf= -.5*Z'*(Sigma\Z) - .5*log(2*pi)*length(Mu) - .5*log(det(Sigma));
    glpdf = -Sigma\Z;
end