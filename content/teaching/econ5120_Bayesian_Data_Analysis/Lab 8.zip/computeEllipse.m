% Helper function to compute ellipse points (if needed)
function [hpdX, hpdY] = computeEllipse(X1, X2, level)
    % Calculate covariance and mean
    covMatrix = cov(X1, X2);
    meanVec = [mean(X1), mean(X2)];

    % Compute ellipse points (based on level, e.g., 90%)
    t = linspace(0, 2*pi, 100);
    [eigVec, eigVal] = eig(covMatrix);
    radii = sqrt(diag(eigVal)) * sqrt(-2 * log(1 - level));
    ellipse = [cos(t) * radii(1); sin(t) * radii(2)]' * eigVec' + meanVec;
    hpdX = ellipse(:, 1);
    hpdY = ellipse(:, 2);
end