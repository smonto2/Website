function [glpdf] = gradlogpdfNormal(theta,Mu,Sigma)
    Z = theta - Mu;
    glpdf = -Sigma\Z;
end