function [resdraws] = rats_gibbs(rats,X,initVals)

[nn,kk] = size(rats);

% Declare prior hyperparameters
a = 3;
b = 1/(2*20);  
eta = [100 15]';
C = [40^2 0; 0 10^2];
rho =5;
R = [10^2 0; 0 .5^2];

% Input values for the MCMC algorithm
niter = 10000; 
burnin = 500; 
nsim = burnin + niter + 1;
keep = (burnin + 2):nsim; % Iterations to keep

% Create objects to be filled in main simulation loop
sigma2 = zeros(1,nsim);
theta0 = zeros(2,nsim);
theta_int = zeros(30,nsim);
theta_rate = zeros(30,nsim);
invSigma = zeros(2,2,nsim);

var_int = zeros(1,nsim);
var_rate = zeros(1,nsim);
correl = zeros(1,nsim);

% Set initial conditions
sigma2(1) = 20;
invSigma(:,:,1) = inv(initVals.initSigma);
theta0(:,1) = initVals.inittheta0;

%==========================================================================
%=====================| GIBBS MAIN LOOP START HERE |=======================
for r = 2:nsim
    total_sse = 0;
    %-----------------------
    % (1) sample all theta_i
    %-----------------------
    for i=1:30
        Dtemp = inv(X'*X/sigma2(r-1) + invSigma(:,:,r-1) );
        dtemp = X'*rats(i,2:kk)'/sigma2(r-1) + invSigma(:,:,r-1)*theta0(:,r-1);
        H = chol(Dtemp);
        theta_temp = Dtemp*dtemp + H'*randn(2,1);
        theta_int(i,r) = theta_temp(1);
        theta_rate(i,r) = theta_temp(2);    
    
        % use this later for sigma^2 conditional
        resids =rats(i,2:kk)' - X*[theta_int(i,r) theta_rate(i,r)]';
        tempp = sum(resids.^2);
        total_sse = total_sse+tempp;
    end
    thetabar = [mean(theta_int(:,r)) mean(theta_rate(:,r))]';
    
    %------------------
    % (2) sample theta0
    %------------------
    Dtemp = inv(30*invSigma(:,:,r-1) + inv(C));
    dtemp = 30*invSigma(:,:,r-1)*thetabar + inv(C)*eta;
    H = chol(Dtemp);
    theta0(:,r) = Dtemp*dtemp + H'*randn(2,1);
    
    %------------------
    % (3) sample sigma2
    %------------------
    sigma2(r) = invgamrnd((150/2)+a, .5*total_sse + inv(b),1,1);
    
    %--------------------
    % (4) sample Sigma^-1
    %--------------------
    tempp3 = 0;
    for ii = 1:30
        tempp1 = [theta_int(ii,r) theta_rate(ii,r)]' - theta0(:,r);
        tempp2 = tempp1*tempp1';
        tempp3 = tempp3 + tempp2;
    end
    invSigma(:,:,r) = wish_rnd(inv(tempp3 + rho*R), 30+rho);
    
    Sigma = inv(invSigma(:,:,r));
    var_int(r) = Sigma(1,1);
    var_rate(r) = Sigma(2,2);
    correl(r)  = Sigma(1,2)/(sqrt(Sigma(1,1))*sqrt(Sigma(2,2)));
    
end

% Save all simulated draws
names = {'theta0','var_int', 'var_rate','correl','theta_int','theta_rate'};
parms = {theta0, var_int, var_rate, correl, theta_int, theta_rate};
resdraws = cell2struct(parms,names,2);
end